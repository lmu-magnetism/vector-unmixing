close all
clear, clc


% %load 1N end members
data1N=readtable('files/component1N_profiles.csv','FileType','text','HeaderLines',1,'Delimiter',',');
data1N.Properties.VariableNames={'steps','em1','em2','em3','em4','em5','em6','em7','em8','em9','em10','em11','em12'};

% %load 1R end members
data1R=readtable('files/component1R_profiles.csv','FileType','text','HeaderLines',1,'Delimiter',',');
data1R.Properties.VariableNames={'steps','em1','em2','em3','em4','em5','em6','em7','em8','em9','em10','em11'};

% %load 2 end members
data2=readtable('files/component2_profiles.csv','FileType','text','HeaderLines',1,'Delimiter',',');
data2.Properties.VariableNames={'steps','em1','em2','em3','em4','em5','em6','em7','em8','em9','em10','em11','em12'};

% %load 3 end members
data3=readtable('files/component3_profiles.csv','FileType','text','HeaderLines',1,'Delimiter',',');
data3.Properties.VariableNames={'steps','em1','em2','em3','em4','em5','em6','em7','em8','em9',...
    'em10','em11','em12','em13','em14','em15','em16','em17','em18','em19',...
    'em20','em21','em22','em23','em24','em25','em26','em27','em28','em29','em30'};

array1N=table2array(data1N(:,2:end));
array1R=table2array(data1R(:,2:end));
array2=table2array(data2(:,2:end));
array3=table2array(data3(:,2:end));

f1=figure;
subplot(2,2,1)
for i=1:size(array1N,2)
    plot(data1N.steps,smooth(array1N(:,i)/array1N(1,i)))
    hold on
end
set(gcf,'Color','w')
title('a) Component 1N end members after subtraction (normalised)')
xlabel(['Temperature step (' char(176) 'C)'])
ylabel('Total moment (M/Mo)')
ylim([0 1.2])

subplot(2,2,2)
for i=1:size(array1R,2)
    plot(data1R.steps,smooth(array1R(:,i)/array1R(1,i)))
    hold on
end
set(gcf,'Color','w')
title('b) Component 1R end members after subtraction (normalised)')
xlabel(['Temperature step (' char(176) 'C)'])
ylabel('Total moment (M/Mo)')
ylim([0 1.2])
    
subplot(2,2,3)
for i=1:size(array2,2)
    plot(data2.steps,smooth(array2(:,i)/array2(1,i)))
    hold on
end
set(gcf,'Color','w')
title('c) Component 2 end members after subtraction (normalised)')
xlabel(['Temperature step (' char(176) 'C)'])
ylabel('Total moment (M/Mo)')
ylim([0 1.2])

subplot(2,2,4)
for i=1:size(array3,2)
    plot(data3.steps,smooth(array3(:,i)/array3(1,i)))
    hold on
end
set(gcf,'Color','w')
title('d) Component 3 end members (normalised)')
xlabel(['Temperature step (' char(176) 'C)'])
ylabel('Total moment (M/Mo)')
ylim([0 1.2])


x0=10;
y0=50;
width=1300;
height=780;
set(gcf,'position',[x0,y0,width,height])



set(f1,'Units','points');
pos = get(f1,'Position');
set(f1,'PaperPositionMode','Auto','PaperUnits','points','PaperSize',[pos(3), pos(4)])
print(f1,'export/hunan_totals.pdf','-dpdf','-r0')




