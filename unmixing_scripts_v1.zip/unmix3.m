close all
clear, clc


%load input curves
data=readtable('files/ref_curves2.csv','FileType','text','HeaderLines',1,'Delimiter',',');
data.Properties.VariableNames={'steps','ht','lt','sd','md'};


%load mixed component
data2=readtable('files/a33_c33_d33.csv','FileType','text','HeaderLines',1,'Delimiter',',');
data2.Properties.VariableNames={'steps','xmix','ymix','zmix','mmix'};


%ENTER SIZE OF 3D MATRIX
resolution=40; %points per 100, this gets cubed and computationally expensive
%more than 40 takes a long time


%ENTER END MEMBER DIRECTIONS HERE

%component A
Da=13;    %dec
Ia=77;    %inc
Ashape=data.ht;

%component B
Db=193;   %dec
Ib=-77;     %inc
Bshape=data.ht;

%component C
Dc=138;     %dec
Ic=-46;     %inc
Cshape=data.lt;


%component D
Dd=6;     %dec
Id=4;     %inc
Dshape=data.lt;



%check directions within limits
if Da>360 || Da<-360 || Ia<-90 || Ia>90 
    disp('Warning: directions for component A exceed maximum (-360 > Da > 360, -90 > Ia > 90')
elseif Db>360 || Db<-360 || Ib<-90 || Ib>90 
    disp('Warning: directions for component B exceed limits (-360 > Db > 360, -90 > Ib > 90')
elseif Dc>360 || Dc<-360 || Ic<-90 || Ic>90 
    disp('Warning: directions for component C exceed limits (-360 > Dc > 360, -90 > Ic > 90')
elseif Dd>360 || Dd<-360 || Id<-90 || Id>90 
    disp('Warning: directions for component D exceed limits (-360 > Dd > 360, -90 > Id > 90')
end



%START COMPONENT A

%apply directions to component A and convert steps to Cartesian (XYZ) coordinates
data.xa=zeros(height(data),1);
data.ya=zeros(height(data),1);
data.za=zeros(height(data),1);

for i=1:length(data.steps)
    data.xa(i)=cosd(Ia)*cosd(Da)*Ashape(i);
    data.ya(i)=cosd(Ia)*sind(Da)*Ashape(i);
    data.za(i)=sind(Ia)*Ashape(i);
end

%check data
if sum(Ashape)==0
    disp('Warning: no data entered for component A')
end



    %START COMPONENT B

%apply directions to component B and convert steps to Cartesian (XYZ) coordinates
data.xb=zeros(height(data),1);
data.yb=zeros(height(data),1);
data.zb=zeros(height(data),1);

for i=1:length(data.steps)
    data.xb(i)=cosd(Ib)*cosd(Db)*Bshape(i);
    data.yb(i)=cosd(Ib)*sind(Db)*Bshape(i);
    data.zb(i)=sind(Ib)*Bshape(i);
end

%check data
if sum(Bshape)==0
    disp('Warning: no data entered for component B')
end
    
    
    

%START COMPONENT C

%apply directions to component C and convert steps to Cartesian (XYZ) coordinates
data.xc=zeros(height(data),1);
data.yc=zeros(height(data),1);
data.zc=zeros(height(data),1);

for i=1:length(data.steps)
    data.xc(i)=cosd(Ic)*cosd(Dc)*Cshape(i);
    data.yc(i)=cosd(Ic)*sind(Dc)*Cshape(i);
    data.zc(i)=sind(Ic)*Cshape(i);
end


if sum(Cshape)==0
    disp('Warning: no data entered for component C')
end


%START COMPONENT D

%apply directions to component D and convert steps to Cartesian (XYZ) coordinates

data.xd=zeros(height(data),1);
data.yd=zeros(height(data),1);
data.zd=zeros(height(data),1);

for i=1:length(data.steps)
    data.xd(i)=cosd(Id)*cosd(Dd)*Dshape(i);
    data.yd(i)=cosd(Id)*sind(Dd)*Dshape(i);
    data.zd(i)=sind(Id)*Dshape(i);
end


if sum(Dshape)==0
    disp('Warning: no data entered for component D')
end
    


 
% %PLOT INPUT COMPONENT
% %zijderveld
f1=figure;
set(gcf,'Color','w')
subplot(4,6,[1 2 7 8])

 
 plot(data2.xmix,-data2.ymix,'k.-','MarkerSize',15)
 hold on
 plot(data2.xmix,-data2.zmix,'ko-','MarkerSize',5)
 title('a) Input (33% A + 33% C + 33% D)')
 box off

% %set x limits
 all_values=[abs(data2.xmix);abs(data2.ymix);abs(data2.zmix)];
 max_value=1.2*max(all_values);
 if max_value==0
     max_value=1;
 else
 xlim([-max_value max_value])
 ylim([-max_value max_value])
 end
 
% %define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E'));
text(-max_value,0.95*-max_value,ticksize);
% 
% %plot axes
 plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')

% %axes labels
text(0.04*max_value,.95*max_value,'Up')
text(-0.1*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.1*max_value,-.93*max_value,'E')
text(-0.97*max_value,0.07*max_value,'S')
text(0.91*max_value,0.07*max_value,'N')


% %remanence plot
subplot(4,6,3)
plot(data2.steps,data2.mmix./data2.mmix(1),'k.-')
if max(data2.mmix)==0
xlim([0 1.1*max(data2.steps)])
ylim([0 1.1])
else
xlim([0 1.1*max(data2.steps)])
ylim([0 1.1*max(data2.mmix./data2.mmix(1))])
end
grid off
box off
xlabel('step ({\circ}C)')
Mo=strcat('Mo=',num2str(data2.mmix(1),'%.2E'));
text(0.05*max(data2.steps),0.095,Mo);


% %stereonet subplot
data2.Imix=zeros(height(data2),1);
data2.Dmix=zeros(height(data2),1);

% %convert to polar coordinates
for i=1:length(data2.steps)
    data2.Imix(i)=-(rad2deg(acos(data2.zmix(i)/sqrt(data2.xmix(i)^2+data2.ymix(i)^2+data2.zmix(i)^2)))-90);
    data2.Dmix(i)=wrapTo360(rad2deg(atan2(data2.ymix(i),data2.xmix(i))));
end


% subplot(6,6,33)
subplot(4,6,9)
    first_time=0;
for i=1:length(data2.steps)
    if first_time==0
          hold off
          first_time=1;
    else
          hold on
    end
       
if data2.Imix(i)<=0
    polarplot(deg2rad(data2.Dmix(i)),-data2.Imix(i),'ko-','MarkerSize',5)
elseif data2.Imix(i)>0
    polarplot(deg2rad(data2.Dmix(i)),data2.Imix(i),'k.-','MarkerSize',15)
else
    polarplot(NaN,NaN)
end

end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};
h = zeros(2, 1);
h(1) = polarplot(NaN,NaN,'k.','MarkerSize',15);
h(2) = polarplot(NaN,NaN,'ko','MarkerSize',5);

% %END plot input





%make grid
points=resolution+1;

residual=zeros(points,points,points);
for i=1:points
    for j=1:points
        for k=1:points
        array.x=1/resolution*(i-1)*data.xa+1/resolution*(j-1)*data.xc+1/resolution*(k-1)*data.xd;
        array.y=1/resolution*(i-1)*data.ya+1/resolution*(j-1)*data.yc+1/resolution*(k-1)*data.yd;
        array.z=1/resolution*(i-1)*data.za+1/resolution*(j-1)*data.zc+1/resolution*(k-1)*data.zd;    
        
        subtract.x=data2.xmix-array.x;
        subtract.y=data2.ymix-array.y;
        subtract.z=data2.zmix-array.z;
        subtract.m=sqrt(subtract.x.^2+subtract.y.^2+subtract.z.^2);
        
        residual(i,j,k)=sum(subtract.m);
        end
    end
end


subplot(4,6,[13 15 19 21])
 [X,Y,Z] = ndgrid(1:size(residual,1), 1:size(residual,2), 1:size(residual,3));
pointsize = 1;
scatter3(X(:), Y(:), Z(:), pointsize, residual(:));
 
xlabel('A weight (%)','Rotation',16)
ylabel('C weight (%)','Rotation',-27)
zlabel('D weight (%)')


xlim([1 points])
ylim([1 points])
zlim([1 points])

xticks([1:resolution/5:points])
yticks([1:resolution/5:points])
zticks([1:resolution/5:points])

xticklabels([0:20:100])
yticklabels([0:20:100])
zticklabels([0:20:100])


title('c) Unmixing residuals (40x40x40 matrix)')
 c = colorbar;
 c.Label.String = 'sum of residuals (arbitrary units) ';
 set(gcf,'Color','w')
 set(colorbar,'visible','off')
 
 [v,loc]=min(residual(:));
 [ii,jj,k] = ind2sub(size(residual),loc);
A_weighting=1/resolution*(ii-1);
C_weighting=1/resolution*(jj-1);
D_weighting=1/resolution*(k-1);
smallest=min(residual(:));
largest=max(residual(:));

grid on
 caxis([smallest largest])

 
subplot(4,6,[16 18 22 24])

%switch X and Y axes to match ndgrid convention
residual = permute(residual,[2 1 3]);
hold on
limit5=0.05; %bounding isosurface 
isosurface(residual,limit5*(largest-smallest)+smallest);

 
xlabel('A weight (%)','Rotation',16)
ylabel('C weight (%)','Rotation',-27)
zlabel('D weight (%)')


xlim([1 points])
ylim([1 points])
zlim([1 points])

xticks([1:resolution/5:points])
yticks([1:resolution/5:points])
zticks([1:resolution/5:points])

xticklabels([0:20:100])
yticklabels([0:20:100])
zticklabels([0:20:100])



grid on

title('d) Unmixing residuals (5% isosurface)')
  c = colorbar;
 c.Label.String = 'sum of residuals (arbitrary units)';
 set(gcf,'Color','w')
 caxis([smallest largest])
view(3);
camlight;
lighting gouraud;

result=sum(sum(sum(residual<=(0.05*largest))));
precision=(1-result/resolution^3)*100;


%best fitting component
data2.xfit=A_weighting*data.xa+C_weighting*data.xc+D_weighting*data.xd;
data2.yfit=A_weighting*data.ya+C_weighting*data.yc+D_weighting*data.yd;
data2.zfit=A_weighting*data.za+C_weighting*data.zc+D_weighting*data.zd;
data2.mfit=sqrt(data2.xfit.^2+data2.yfit.^2+data2.zfit.^2);

% %PLOT OUTPUT COMPONENT
% %zijderveld

subplot(4,6,[4 5 10 11])

 plot(data2.xfit,-data2.yfit,'k.-','MarkerSize',15)
 hold on
 plot(data2.xfit,-data2.zfit,'ko-','MarkerSize',5)
 title('b) Output (best fitting combination)')
 box off

% %set x limits
 all_values=[abs(data2.xfit);abs(data2.yfit);abs(data2.zfit)];
 max_value=1.2*max(all_values);
 if max_value==0
     max_value=1;
 else
 xlim([-max_value max_value])
 ylim([-max_value max_value])
 end
 
% %define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E'));
text(-max_value,0.95*-max_value,ticksize);
% 
% %plot axes
 plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')

% %axes labels
text(0.04*max_value,.95*max_value,'Up')
text(-0.1*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.1*max_value,-.93*max_value,'E')
text(-0.97*max_value,0.07*max_value,'S')
text(0.91*max_value,0.07*max_value,'N')


% %remanence plot
subplot(4,6,6)
plot(data2.steps,data2.mfit./data2.mfit(1),'k.-')
if max(data2.mfit)==0
xlim([0 1.1*max(data2.steps)])
ylim([0 1.1])
else
xlim([0 1.1*max(data2.steps)])
ylim([0 1.1*max(data2.mfit./data2.mfit(1))])
end
grid off
box off
xlabel('step ({\circ}C)')
Mo=strcat('Mo=',num2str(data2.mfit(1),'%.2E'));
text(0.05*max(data2.steps),0.095,Mo);


% %stereonet subplot
% %convert to polar coordinates
data2.Ifit=zeros(height(data2),1);
data2.Dfit=zeros(height(data2),1);

for i=1:length(data2.steps)
    data2.Ifit(i)=-(rad2deg(acos(data2.zfit(i)/sqrt(data2.xfit(i)^2+data2.yfit(i)^2+data2.zfit(i)^2)))-90);
    data2.Dfit(i)=wrapTo360(rad2deg(atan2(data2.yfit(i),data2.xfit(i))));
end


subplot(4,6,12)
    first_time=0;
for i=1:length(data2.steps)
    if first_time==0
          hold off
          first_time=1;
    else
          hold on
    end
       
if data2.Ifit(i)<=0
    polarplot(deg2rad(data2.Dfit(i)),-data2.Ifit(i),'ko-','MarkerSize',5)
elseif data2.Ifit(i)>0
    polarplot(deg2rad(data2.Dfit(i)),data2.Ifit(i),'k.-','MarkerSize',15)
else
    polarplot(NaN,NaN)
end

end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};
h = zeros(2, 1);
h(1) = polarplot(NaN,NaN,'k.','MarkerSize',15);
h(2) = polarplot(NaN,NaN,'ko','MarkerSize',5);


%format
x0=10;
y0=50;
width=1400;
height=850;
set(gcf,'position',[x0,y0,width,height])

%export
set(f1,'Units','Inches');
pos = get(f1,'Position');
set(f1,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
saveas(gcf, 'export/unmix3.pdf', 'pdf')  

