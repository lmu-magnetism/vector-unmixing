close all
clear, clc

%load reference curves
data=readtable('files/ref_curves2.csv','FileType','text','HeaderLines',1,'Delimiter',',');
data.Properties.VariableNames={'steps','ht','lt','sd','md'};


%ENTER DIRECTIONS HERE

%component A
Da=13;    %dec
Ia=77;    %inc
Ashape=data.ht;


%component B
Db=193;   %dec
Ib=-77;     %inc
Bshape=data.ht;

%component C
Dc=138;     %dec
Ic=-46;     %inc
Cshape=data.lt;

%component D
Dd=6;     %dec
Id=4;     %inc
Dshape=data.lt;




%check directions within limits
if Da>360 || Da<-360 || Ia<-90 || Ia>90 
    disp('Warning: directions for component A exceed maximum (-360 > Da > 360, -90 > Ia > 90')
elseif Db>360 || Db<-360 || Ib<-90 || Ib>90 
    disp('Warning: directions for component B exceed limits (-360 > Db > 360, -90 > Ib > 90')
elseif Dc>360 || Dc<-360 || Ic<-90 || Ic>90 
    disp('Warning: directions for component C exceed limits (-360 > Dc > 360, -90 > Ic > 90')
elseif Dd>360 || Dd<-360 || Id<-90 || Id>90 
    disp('Warning: directions for component D exceed limits (-360 > Dd > 360, -90 > Id > 90')
end



%START COMPONENT A

%apply directions to component A and convert steps to Cartesian (XYZ) coordinates
data.xa=zeros(height(data),1);
data.ya=zeros(height(data),1);
data.za=zeros(height(data),1);

for i=1:length(data.steps)
    data.xa(i)=cosd(Ia)*cosd(Da)*Ashape(i);
    data.ya(i)=cosd(Ia)*sind(Da)*Ashape(i);
    data.za(i)=sind(Ia)*Ashape(i);
end

%check data
if sum(Ashape)==0
    disp('Warning: no data entered for component A')
else


%plot component A

%zijderveld
f1=figure;
subplot(4,6,[1 2 7 8])
set(gcf,'Color','w')
plot(data.xa,-data.ya,'k.-','MarkerSize',15)
hold on
plot(data.xa,-data.za,'ko-','MarkerSize',5)
title('a) Input component A')
box off

%set xy limits
all_values=[abs(data.xa);abs(data.ya);abs(data.za)];
max_value=1.2*max(all_values);
if max_value==0
    max_value=1;
else
xlim([-max_value max_value])
ylim([-max_value max_value])
end


%define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E'));
text(-max_value,0.95*-max_value,ticksize);

%plot axes
plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')

text(0.04*max_value,.95*max_value,'Up')
text(-0.1*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.1*max_value,-.93*max_value,'E')
text(-0.97*max_value,0.07*max_value,'S')
text(0.91*max_value,0.07*max_value,'N')


%remanence plot
subplot(4,6,3)
plot(data.steps,Ashape,'k.-')
xlim([0 1.1*max(data.steps)])
ylim([0 1.1*max(Ashape)])
grid off
box off
ylabel('M/Mo')
xlabel('step ({\circ}C)')
Mo=strcat('Mo=',num2str(Ashape(1),'%.2E'));
text(0.05*max(data.steps),0.095,Mo);

%stereonet
subplot(4,6,9)
if Ia<=0
    polarplot(deg2rad(Da),-Ia,'ko','MarkerSize',5)
elseif Ia>0 
    polarplot(deg2rad(Da),Ia,'k.','MarkerSize',15)
else
    polarplot(NaN,NaN)
end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};
ax.ThetaColor = 'k';
h = zeros(2, 1);
hold on
h(1) = polarplot(NaN,NaN,'k.','MarkerSize',15);
h(2) = polarplot(NaN,NaN,'ko','MarkerSize',5);
end

%END COMPONENT A



%START COMPONENT B

%apply directions to component B and convert steps to Cartesian (XYZ) coordinates
data.xb=zeros(height(data),1);
data.yb=zeros(height(data),1);
data.zb=zeros(height(data),1);

for i=1:length(data.steps)
    data.xb(i)=cosd(Ib)*cosd(Db)*Bshape(i);
    data.yb(i)=cosd(Ib)*sind(Db)*Bshape(i);
    data.zb(i)=sind(Ib)*Bshape(i);
end

%check data
if sum(Bshape)==0
    disp('Warning: no data entered for component B')
else

%plot component B

%zijderveld
subplot(4,6,[4 5 10 11])
set(gcf,'Color','w');
plot(data.xb,-data.yb,'k.-','MarkerSize',15)
hold on
plot(data.xb,-data.zb,'ko-','MarkerSize',5)
title('b) Input component B')
box off


%set xy limits
all_values=[abs(data.xb);abs(data.yb);abs(data.zb)];
max_value=1.2*max(all_values);
if max_value==0
    max_value=1;
else
xlim([-max_value max_value])
ylim([-max_value max_value])
end


%define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E'));
text(-max_value,0.95*-max_value,ticksize);

%plot axes
plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')


text(0.04*max_value,.95*max_value,'Up')
text(-0.1*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.1*max_value,-.93*max_value,'E')
text(-0.97*max_value,0.07*max_value,'S')
text(0.91*max_value,0.07*max_value,'N')


%remanence plot
subplot(4,6,6)
plot(data.steps,Bshape,'k.-')
xlim([0 1.1*max(data.steps)])
ylim([0 1.1*max(Bshape)])
grid off
box off
ylabel('M/Mo')
xlabel('step ({\circ}C)')
Mo=strcat('Mo=',num2str(Bshape(1),'%.2E'));
text(0.05*max(data.steps),0.095,Mo);

%stereonet
subplot(4,6,12)
if Ib<=0
    polarplot(deg2rad(Db),-Ib,'ko','MarkerSize',5)
elseif Ib>0
    polarplot(deg2rad(Db),Ib,'k.','MarkerSize',15)
else
    polarplot(NaN,NaN)
end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};
ax.ThetaColor = 'k';
h = zeros(2, 1);
hold on
h(1) = polarplot(NaN,NaN,'k.','MarkerSize',15);
h(2) = polarplot(NaN,NaN,'ko','MarkerSize',5);
end

%END COMPONENT B



%START COMPONENT C

%apply directions to component C and convert steps to Cartesian (XYZ) coordinates
data.xc=zeros(height(data),1);
data.yc=zeros(height(data),1);
data.zc=zeros(height(data),1);

for i=1:length(data.steps)
    data.xc(i)=cosd(Ic)*cosd(Dc)*Cshape(i);
    data.yc(i)=cosd(Ic)*sind(Dc)*Cshape(i);
    data.zc(i)=sind(Ic)*Cshape(i);
end


if sum(Cshape)==0
    disp('Warning: no data entered for component C')
else
    
%plot component C

%zijderveld
subplot(4,6,[13 14 19 20])
set(gcf,'Color','w');
plot(data.xc,-data.yc,'k.-','MarkerSize',15)
hold on
plot(data.xc,-data.zc,'ko-','MarkerSize',5)
title('c) Input component C')
box off


%set x limits
all_values=[abs(data.xc);abs(data.yc);abs(data.zc)];
max_value=1.2*max(all_values);
if max_value==0
    max_value=1;
else
xlim([-max_value max_value])
ylim([-max_value max_value])
end


%define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E'));
text(-max_value,0.95*-max_value,ticksize);


%plot axes
plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')


text(0.04*max_value,.95*max_value,'Up')
text(-0.1*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.1*max_value,-.93*max_value,'E')
text(-0.97*max_value,0.07*max_value,'S')
text(0.91*max_value,0.07*max_value,'N')


%remanence plot
subplot(4,6,15)
plot(data.steps,Cshape,'k.-')
xlim([0 1.1*max(data.steps)])
ylim([0 1.1*max(Cshape)])
grid off
box off
ylabel('M/Mo')
xlabel('step ({\circ}C)')
Mo=strcat('Mo=',num2str(Cshape(1),'%.2E'));
text(0.05*max(data.steps),0.095,Mo);

%stereonet
subplot(4,6,21)
if Ic<=0
    polarplot(deg2rad(Dc),-Ic,'ko','MarkerSize',5)
elseif Ic>0
    polarplot(deg2rad(Dc),Ic,'k.','MarkerSize',15)
else
    polarplot(NaN,NaN)
end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};
h = zeros(2, 1);
hold on
h(1) = polarplot(NaN,NaN,'k.','MarkerSize',15);
h(2) = polarplot(NaN,NaN,'ko','MarkerSize',5);
end
%END COMPONENT C



%START COMPONENT D

data.xd=zeros(height(data),1);
data.yd=zeros(height(data),1);
data.zd=zeros(height(data),1);

for i=1:length(data.steps)
    data.xd(i)=cosd(Id)*cosd(Dd)*Dshape(i);
    data.yd(i)=cosd(Id)*sind(Dd)*Dshape(i);
    data.zd(i)=sind(Id)*Dshape(i);
end


if sum(Dshape)==0
    disp('Warning: no data entered for component D')
else
    
%plot component D

%zijderveld
subplot(4,6,[16 17 22 23])
set(gcf,'Color','w');
plot(data.xd,-data.yd,'k.-','MarkerSize',15)
hold on
plot(data.xd,-data.zd,'ko-','MarkerSize',5)
title('d) Input component D')
box off


%set x limits
all_values=[abs(data.xd);abs(data.yd);abs(data.zd)];
max_value=1.2*max(all_values);
if max_value==0
    max_value=1;
else
xlim([-max_value max_value])
ylim([-max_value max_value])
end


%define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E'));
text(-max_value,0.95*-max_value,ticksize);


%plot axes
plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')


text(0.04*max_value,.95*max_value,'Up')
text(-0.1*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.1*max_value,-.93*max_value,'E')
text(-0.97*max_value,0.07*max_value,'S')
text(0.91*max_value,0.07*max_value,'N')


%remanence plot
subplot(4,6,18)
plot(data.steps,Dshape,'k.-')
xlim([0 1.1*max(data.steps)])
ylim([0 1.1*max(Dshape)])
grid off
box off
ylabel('M/Mo')
xlabel('step ({\circ}C)')
Mo=strcat('Mo=',num2str(Dshape(1),'%.2E'));
text(0.05*max(data.steps),0.095,Mo);

%stereonet
subplot(4,6,24)
if Id<=0
    polarplot(deg2rad(Dd),-Id,'ko','MarkerSize',5)
elseif Id>0
    polarplot(deg2rad(Dd),Id,'k.','MarkerSize',15)
else
    polarplot(NaN,NaN)
end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};
h = zeros(2, 1);
hold on
h(1) = polarplot(NaN,NaN,'k.','MarkerSize',15);
h(2) = polarplot(NaN,NaN,'ko','MarkerSize',5);
end
%END COMPONENT D



%format
x0=10;
y0=50;
width=1600;
height=950;
set(gcf,'position',[x0,y0,width,height])


%export
set(f1,'Units','Inches');
pos = get(f1,'Position');
set(f1,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(f1,'export/synthetic1a.pdf','-dpdf','-r0')




%COMBINED COMPONENTS

%START COMPONENT AC

weight=0.5;
for i=1:length(data.steps)
    xdata(i)=weight*data.xa(i)+weight*data.xc(i);
    ydata(i)=weight*data.ya(i)+weight*data.yc(i);
    zdata(i)=weight*data.za(i)+weight*data.zc(i);
    mdata(i)=sqrt(xdata(i)^2+ydata(i)^2+zdata(i)^2);
end

%plot component AC

%zijderveld
f2=figure;
subplot(4,6,[1 2 7 8])
set(gcf,'Color','w')
plot(xdata,-ydata,'k.-','MarkerSize',15)
hold on
plot(xdata,-zdata,'ko-','MarkerSize',5)
title('e) 50% A + 50% C')
box off

%set xy limits
all_values=[max(abs(xdata));max(abs(ydata));max(abs(zdata))];
max_value=1.2*max(all_values);
if max_value==0
    max_value=1;
else
xlim([-max_value max_value])
ylim([-max_value max_value])
end


%define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E'));
text(-max_value,0.95*-max_value,ticksize);

%plot axes
plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')

text(0.04*max_value,.95*max_value,'Up')
text(-0.1*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.1*max_value,-.93*max_value,'E')
text(-0.97*max_value,0.07*max_value,'S')
text(0.91*max_value,0.07*max_value,'N')


%remanence plot
subplot(4,6,3)
plot(data.steps,mdata./mdata(1),'k.-')
xlim([0 1.1*max(data.steps)])
ylim([0 1.1*max(mdata./mdata(1))])
grid off
box off
ylabel('M/Mo')
xlabel('step ({\circ}C)')
Mo=strcat('Mo=',num2str(mdata(1),'%.2E'));
text(0.05*max(data.steps),0.095,Mo);

%stereonet
data.I=zeros(length(data.steps),1);
data.D=zeros(length(data.steps),1);
for i=1:length(data.steps)
    data.I(i)=-(rad2deg(acos(zdata(i)/sqrt(xdata(i)^2+ydata(i)^2+zdata(i)^2)))-90);
    data.D(i)=wrapTo360(rad2deg(atan2(ydata(i),xdata(i))));
end


subplot(4,6,9)
  first_time=0;
for i=1:length(data.steps)
    if first_time==0
          hold off
          first_time=1;
    else
          hold on
    end
%        
if data.I(i)<=0
    polarplot(deg2rad(data.D(i)),-data.I(i),'ko-','MarkerSize',5)
elseif data.I(i)>0
    polarplot(deg2rad(data.D(i)),data.I(i),'k.-','MarkerSize',15)
else
    polarplot(NaN,NaN)
end

end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};
h = zeros(2, 1);
h(1) = polarplot(NaN,NaN,'k.','MarkerSize',15);
h(2) = polarplot(NaN,NaN,'ko','MarkerSize',5);

%END COMPONENT AC





%START COMPONENT BC

weight=0.5;
for i=1:length(data.steps)
    xdata(i)=weight*data.xb(i)+weight*data.xc(i);
    ydata(i)=weight*data.yb(i)+weight*data.yc(i);
    zdata(i)=weight*data.zb(i)+weight*data.zc(i);
    mdata(i)=sqrt(xdata(i)^2+ydata(i)^2+zdata(i)^2);
end

%plot component BC

%zijderveld
subplot(4,6,[4 5 10 11])
set(gcf,'Color','w')
plot(xdata,-ydata,'k.-','MarkerSize',15)
hold on
plot(xdata,-zdata,'ko-','MarkerSize',5)
title('f) 50% B + 50% C')
box off

%set xy limits
all_values=[max(abs(xdata));max(abs(ydata));max(abs(zdata))];
max_value=1.2*max(all_values);
if max_value==0
    max_value=1;
else
xlim([-max_value max_value])
ylim([-max_value max_value])
end


%define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E'));
text(-max_value,0.95*-max_value,ticksize);

%plot axes
plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')

text(0.04*max_value,.95*max_value,'Up')
text(-0.1*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.1*max_value,-.93*max_value,'E')
text(-0.97*max_value,0.07*max_value,'S')
text(0.91*max_value,0.07*max_value,'N')


%remanence plot
subplot(4,6,6)
plot(data.steps,mdata./mdata(1),'k.-')
xlim([0 1.1*max(data.steps)])
ylim([0 1.1*max(mdata./mdata(1))])
grid off
box off
ylabel('M/Mo')
xlabel('step ({\circ}C)')
Mo=strcat('Mo=',num2str(mdata(1),'%.2E'));
text(0.05*max(data.steps),0.095,Mo);

%stereonet
data.I=zeros(length(data.steps),1);
data.D=zeros(length(data.steps),1);
for i=1:length(data.steps)
    data.I(i)=-(rad2deg(acos(zdata(i)/sqrt(xdata(i)^2+ydata(i)^2+zdata(i)^2)))-90);
    data.D(i)=wrapTo360(rad2deg(atan2(ydata(i),xdata(i))));
end

subplot(4,6,12)

  first_time=0;
for i=1:length(data.steps)
    if first_time==0
          hold off
          first_time=1;
    else
          hold on
    end
%        
if data.I(i)<=0
    polarplot(deg2rad(data.D(i)),-data.I(i),'ko-','MarkerSize',5)
elseif data.I(i)>0
    polarplot(deg2rad(data.D(i)),data.I(i),'k.-','MarkerSize',15)
else
    polarplot(NaN,NaN)
end

end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};
h = zeros(2, 1);
h(1) = polarplot(NaN,NaN,'k.','MarkerSize',15);
h(2) = polarplot(NaN,NaN,'ko','MarkerSize',5);

%END COMPONENT BC




%START COMPONENT AD

weight=0.5;
for i=1:length(data.steps)
    xdata(i)=weight*data.xa(i)+weight*data.xd(i);
    ydata(i)=weight*data.ya(i)+weight*data.yd(i);
    zdata(i)=weight*data.za(i)+weight*data.zd(i);
    mdata(i)=sqrt(xdata(i)^2+ydata(i)^2+zdata(i)^2);
end

%zijderveld
subplot(4,6,[13 14 19 20])
set(gcf,'Color','w')
plot(xdata,-ydata,'k.-','MarkerSize',15)
hold on
plot(xdata,-zdata,'ko-','MarkerSize',5)
title('g) 50% A + 50% D')
box off

%set xy limits
all_values=[max(abs(xdata));max(abs(ydata));max(abs(zdata))];
max_value=1.2*max(all_values);
if max_value==0
    max_value=1;
else
xlim([-max_value max_value])
ylim([-max_value max_value])
end


%define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E'));
text(-max_value,0.95*-max_value,ticksize);

%plot axes
plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')

text(0.04*max_value,.95*max_value,'Up')
text(-0.1*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.1*max_value,-.93*max_value,'E')
text(-0.97*max_value,0.07*max_value,'S')
text(0.91*max_value,0.07*max_value,'N')


%remanence plot
subplot(4,6,15)
plot(data.steps,mdata./mdata(1),'k.-')
xlim([0 1.1*max(data.steps)])
ylim([0 1.1*max(mdata./mdata(1))])
grid off
box off
ylabel('M/Mo')
xlabel('step ({\circ}C)')
Mo=strcat('Mo=',num2str(mdata(1),'%.2E'));
text(0.05*max(data.steps),0.095,Mo);

%stereonet
data.I=zeros(length(data.steps),1);
data.D=zeros(length(data.steps),1);
for i=1:length(data.steps)
    data.I(i)=-(rad2deg(acos(zdata(i)/sqrt(xdata(i)^2+ydata(i)^2+zdata(i)^2)))-90);
    data.D(i)=wrapTo360(rad2deg(atan2(ydata(i),xdata(i))));
end


subplot(4,6,21)


  first_time=0;
for i=1:length(data.steps)
    if first_time==0
          hold off
          first_time=1;
    else
          hold on
    end
%        
if data.I(i)<=0
    polarplot(deg2rad(data.D(i)),-data.I(i),'ko-','MarkerSize',5)
elseif data.I(i)>0
    polarplot(deg2rad(data.D(i)),data.I(i),'k.-','MarkerSize',15)
else
    polarplot(NaN,NaN)
end

end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};
h = zeros(2, 1);
h(1) = polarplot(NaN,NaN,'k.','MarkerSize',15);
h(2) = polarplot(NaN,NaN,'ko','MarkerSize',5);

%END COMPONENT AD






%START COMPONENT BD

weight=0.5;
for i=1:length(data.steps)
    xdata(i)=weight*data.xb(i)+weight*data.xd(i);
    ydata(i)=weight*data.yb(i)+weight*data.yd(i);
    zdata(i)=weight*data.zb(i)+weight*data.zd(i);
    mdata(i)=sqrt(xdata(i)^2+ydata(i)^2+zdata(i)^2);
end

%zijderveld
subplot(4,6,[16 17 22 23])
set(gcf,'Color','w')
plot(xdata,-ydata,'k.-','MarkerSize',15)
hold on
plot(xdata,-zdata,'ko-','MarkerSize',5)
title('h) 50% B + 50% D')
box off

%set xy limits
all_values=[max(abs(xdata));max(abs(ydata));max(abs(zdata))];
max_value=1.2*max(all_values);
if max_value==0
    max_value=1;
else
xlim([-max_value max_value])
ylim([-max_value max_value])
end


%define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E'));
text(-max_value,0.95*-max_value,ticksize);

%plot axes
plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')

text(0.04*max_value,.95*max_value,'Up')
text(-0.1*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.1*max_value,-.93*max_value,'E')
text(-0.97*max_value,0.07*max_value,'S')
text(0.91*max_value,0.07*max_value,'N')


%remanence plot
subplot(4,6,18)
plot(data.steps,mdata./mdata(1),'k.-')
xlim([0 1.1*max(data.steps)])
ylim([0 1.1*max(mdata./mdata(1))])
grid off
box off
ylabel('M/Mo')
xlabel('step ({\circ}C)')
Mo=strcat('Mo=',num2str(mdata(1),'%.2E'));
text(0.05*max(data.steps),0.095,Mo);

%stereonet
data.I=zeros(length(data.steps),1);
data.D=zeros(length(data.steps),1);
for i=1:length(data.steps)
    data.I(i)=-(rad2deg(acos(zdata(i)/sqrt(xdata(i)^2+ydata(i)^2+zdata(i)^2)))-90);
    data.D(i)=wrapTo360(rad2deg(atan2(ydata(i),xdata(i))));
end



subplot(4,6,24)


  first_time=0;
for i=1:length(data.steps)
    if first_time==0
          hold off
          first_time=1;
    else
          hold on
    end
%        
if data.I(i)<=0
    polarplot(deg2rad(data.D(i)),-data.I(i),'ko-','MarkerSize',5)
elseif data.I(i)>0
    polarplot(deg2rad(data.D(i)),data.I(i),'k.-','MarkerSize',15)
else
    polarplot(NaN,NaN)
end

end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};
h = zeros(2, 1);
h(1) = polarplot(NaN,NaN,'k.','MarkerSize',15);
h(2) = polarplot(NaN,NaN,'ko','MarkerSize',5);

%END COMPONENT BD


%format
x0=10;
y0=50;
width=1600;
height=950;
set(gcf,'position',[x0,y0,width,height])


%export
set(f2,'Units','Inches');
pos = get(f2,'Position');
set(f2,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(f2,'export/synthetic1b.pdf','-dpdf','-r0')