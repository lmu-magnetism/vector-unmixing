close all
clear, clc


%load ref curves
data=readtable('files/ref_curves.csv','FileType','text','HeaderLines',1,'Delimiter',',');
data.Properties.VariableNames={'steps','compA','compB','compC'};


%load mixed component
data2=readtable('files/a50_b00_c50.csv','FileType','text','HeaderLines',1,'Delimiter',',');
data2.Properties.VariableNames={'steps','xmix','ymix','zmix','mmix'};

%enter resolution of fitting matrix
resolution=40;

%ENTER DIRECTIONS HERE

%component A directions
Da=13;    %dec
Ia=77;    %inc

%component B directions
Db=6;   %dec
Ib=4;     %inc

%component C directions
Dc=138;     %dec
Ic=-46;     %inc


%check directions within limits
if Da>360 || Da<-360 || Ia<-90 || Ia>90 
    disp('Warning: directions for component A exceed maximum (-360 > Da > 360, -90 > Ia > 90')
elseif Db>360 || Db<-360 || Ib<-90 || Ib>90 
    disp('Warning: directions for component B exceed limits (-360 > Db > 360, -90 > Ib > 90')
elseif Dc>360 || Dc<-360 || Ic<-90 || Ic>90 
    disp('Warning: directions for component C exceed limits (-360 > Dc > 360, -90 > Ic > 90')
end


%START COMPONENT A

%apply directions to component A and convert steps to Cartesian (XYZ) coordinates
data.xa=zeros(height(data),1);
data.ya=zeros(height(data),1);
data.za=zeros(height(data),1);

for i=1:height(data)
    data.xa(i)=cosd(Ia)*cosd(Da)*data.compA(i);
    data.ya(i)=cosd(Ia)*sind(Da)*data.compA(i);
    data.za(i)=sind(Ia)*data.compA(i);
end

%check data
if sum(data.compA)==0
    disp('Warning: no data entered for component A')
end


    %START COMPONENT B

%apply directions to component B and convert steps to Cartesian (XYZ) coordinates
data.xb=zeros(height(data),1);
data.yb=zeros(height(data),1);
data.zb=zeros(height(data),1);

for i=1:height(data)
    data.xb(i)=cosd(Ib)*cosd(Db)*data.compB(i);
    data.yb(i)=cosd(Ib)*sind(Db)*data.compB(i);
    data.zb(i)=sind(Ib)*data.compB(i);
end

    
    %check data
if sum(data.compB)==0
    disp('Warning: no data entered for component B')
end

    
    

%START COMPONENT C

%apply directions to component C and convert steps to Cartesian (XYZ) coordinates
data.xc=zeros(height(data),1);
data.yc=zeros(height(data),1);
data.zc=zeros(height(data),1);

for i=1:height(data)
    data.xc(i)=cosd(Ic)*cosd(Dc)*data.compC(i);
    data.yc(i)=cosd(Ic)*sind(Dc)*data.compC(i);
    data.zc(i)=sind(Ic)*data.compC(i);
end


if sum(data.compC)==0
    disp('Warning: no data entered for component C')
end



%make grid
points=resolution+1;
residual=zeros(points,points);
for i=1:points;
    for j=1:points;
        array.x=1/resolution*(i-1)*data.xa+1/resolution*(j-1)*data.xc;
        array.y=1/resolution*(i-1)*data.ya+1/resolution*(j-1)*data.yc;
        array.z=1/resolution*(i-1)*data.za+1/resolution*(j-1)*data.zc;    
        
        subtract.x=data2.xmix-array.x;
        subtract.y=data2.ymix-array.y;
        subtract.z=data2.zmix-array.z;
        subtract.m=sqrt(subtract.x.^2+subtract.y.^2+subtract.z.^2);
        
        residual(i,j)=sum(subtract.m);
    end
end

f1=figure;
%plot  contour
%switch X and Y axes to match ndgrid convention
subplot(2,6,[1 3 7 9])
residual = permute(residual,[2 1]);
contourf(residual,resolution)
xticks([1:resolution/5:points])
yticks([1:resolution/5:points])

xlabel('Component A (% weighting)')
ylabel('Component C (% weighting)')

xlim([1 points])
ylim([1 points])

xticklabels([0:20:100])
yticklabels([0:20:100])

title('a) Unmixing A + C components (residuals)')
c = colorbar;
c.Label.String = 'sum of residuals (arbitrary units)';
set(gcf,'Color','w')

smallest_residual=min(residual(:))
[row,col] = find(residual==smallest_residual);
A_weighting=1/resolution*(row-1)
C_weighting=1/resolution*(col-1)



%best fitting component
data2.xfit=A_weighting*data.xa+C_weighting*data.xc;
data2.yfit=A_weighting*data.ya+C_weighting*data.yc;
data2.zfit=A_weighting*data.za+C_weighting*data.zc;
data2.mfit=sqrt(data2.xfit.^2+data2.yfit.^2+data2.zfit.^2);

% %PLOT OUTPUT COMPONENT
% %zijderveld

subplot(2,6,[4 5 10 11])

 plot(data2.xfit,-data2.yfit,'k.-','MarkerSize',15)
 hold on
 plot(data2.xfit,-data2.zfit,'ko-','MarkerSize',5)
 title('b) Output (best fitting combination)')
 box off

% %set x limits
 all_values=[abs(data2.xfit);abs(data2.yfit);abs(data2.zfit)];
 max_value=1.2*max(all_values);
 if max_value==0
     max_value=1;
 else
 xlim([-max_value max_value])
 ylim([-max_value max_value])
 end
 
% %define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E'));
text(-max_value,0.95*-max_value,ticksize);
% 
% %plot axes
 plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')

% %axes labels
text(0.04*max_value,.95*max_value,'Up')
text(-0.1*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.1*max_value,-.93*max_value,'E')
text(-0.97*max_value,0.07*max_value,'S')
text(0.91*max_value,0.07*max_value,'N')


% %remanence plot
subplot(2,6,6)
plot(data2.steps,data2.mfit./data2.mfit(1),'k.-')
if max(data2.mfit)==0
xlim([0 1.1*max(data2.steps)])
ylim([0 1.1])
else
xlim([0 1.1*max(data2.steps)])
ylim([0 1.1*max(data2.mfit./data2.mfit(1))])
end
grid off
box off
xlabel('step ({\circ}C)')
Mo=strcat('Mo=',num2str(data2.mfit(1),'%.2E'));
text(0.05*max(data2.steps),0.095,Mo);


% %stereonet subplot
% %convert to polar coordinates
data2.Ifit=zeros(height(data2),1);
data2.Dfit=zeros(height(data2),1);

for i=1:length(data2.steps)
    data2.Ifit(i)=-(rad2deg(acos(data2.zfit(i)/sqrt(data2.xfit(i)^2+data2.yfit(i)^2+data2.zfit(i)^2)))-90);
    data2.Dfit(i)=wrapTo360(rad2deg(atan2(data2.yfit(i),data2.xfit(i))));
end


subplot(2,6,12)
    first_time=0;
for i=1:length(data2.steps)
    if first_time==0
          hold off
          first_time=1;
    else
          hold on
    end
       
if data2.Ifit(i)<=0
    polarplot(deg2rad(data2.Dfit(i)),-data2.Ifit(i),'ko-','MarkerSize',5)
elseif data2.Ifit(i)>0
    polarplot(deg2rad(data2.Dfit(i)),data2.Ifit(i),'k.-','MarkerSize',15)
else
    polarplot(NaN,NaN)
end

end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};
h = zeros(2, 1);
h(1) = polarplot(NaN,NaN,'k.','MarkerSize',15);
h(2) = polarplot(NaN,NaN,'ko','MarkerSize',5);


%format
x0=10;
y0=50;
width=1400;
height=450;
set(gcf,'position',[x0,y0,width,height])


set(f1,'Units','Inches');
pos = get(f1,'Position');
set(f1,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

%export
set(gcf,'renderer','opengl'); 
saveas(gcf, 'export/unmix2.pdf', 'pdf')  


