close all
clear, clc


%get curves
an_data=readtable('files/hunan_comp1norm_curves.csv','FileType','text','HeaderLines',1,'Delimiter',',');
an_data.Properties.VariableNames={'steps','m_lq','m_median','m_uq','x_lq','x_median','x_uq','y_lq','y_median','y_uq','z_lq','z_median','z_uq'};

ar_data=readtable('files/hunan_comp1rev_curves.csv','FileType','text','HeaderLines',1,'Delimiter',',');
ar_data.Properties.VariableNames={'steps','m_lq','m_median','m_uq','x_lq','x_median','x_uq','y_lq','y_median','y_uq','z_lq','z_median','z_uq'};

b_data=readtable('files/hunan_comp2_curves.csv','FileType','text','HeaderLines',1,'Delimiter',',');
b_data.Properties.VariableNames={'steps','m_lq','m_median','m_uq','x_lq','x_median','x_uq','y_lq','y_median','y_uq','z_lq','z_median','z_uq'};

c_data=readtable('files/hunan_comp3_curves.csv','FileType','text','HeaderLines',1,'Delimiter',',');
c_data.Properties.VariableNames={'steps','m_lq','m_median','m_uq','x_lq','x_median','x_uq','y_lq','y_median','y_uq','z_lq','z_median','z_uq'};


b_weight=0.725; %amount of cretaceous component to subtract from component 2

an_weight=0.585; %amount of cretaceous component to subtract from 1N

ar_weight=0.41; %amount of cretaceous component to subtract from 1R


% % %PLOT B SUBTRACTION
xdata=b_data.x_median-b_weight*c_data.x_median;
ydata=b_data.y_median-b_weight*c_data.y_median;
zdata=b_data.z_median-b_weight*c_data.z_median;
mdata=sqrt(xdata.^2+ydata.^2+zdata.^2);

steps=b_data.steps;
data=b_data;
name=strcat(['f) Component 2 minus ' num2str(b_weight*100) '% of component 3 (TC)']);


% % %zijderveld
f1=figure;
 set(gcf,'Color','w')
 subplot(4,6,[4 5 10 11])

 plot(xdata,-ydata,'k.-','MarkerSize',15)
 hold on
 plot(xdata,-zdata,'ko-','MarkerSize',5)
  title(name)
 box off

% % %set x limits
all_values=[abs(xdata);abs(ydata);abs(zdata)];
max_value=1.2*max(all_values);
 if max_value==0
     max_value=1;
 else
 xlim([-max_value max_value])
 ylim([-max_value max_value])
 end
%  
% % %define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E Am^2/kg'));
text(-max_value,0.95*-max_value,ticksize);

% % 
% % %plot axes
 plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')

% % %axes labels
text(0.04*max_value,.95*max_value,'Up')
text(-0.1*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.09*max_value,-.93*max_value,'E')
text(-0.97*max_value,0.06*max_value,'S')
text(0.91*max_value,0.06*max_value,'N')


% % %remanence plot
subplot(4,6,6)
plot(steps,mdata./mdata(1),'k.-')
if max(mdata)==0
xlim([0 1.1*max(steps)])
ylim([0 1.1])
else
xlim([0 1.1*max(steps)])
ylim([0 1.1*max(mdata./mdata(1))])
end
grid off
box off
ylabel('M/Mo')
xlabel('step ({\circ}C)')
Mo=strcat('Mo=',num2str(mdata(1),'%.2E Am^2/kg'));
text(0.05*max(steps),1.2,Mo);


% % %stereonet subplot
data.I=zeros(height(data),1);
data.D=zeros(height(data),1);
% 
% % %convert to polar coordinates
for i=1:length(steps)
    data.I(i)=-(rad2deg(acos(zdata(i)/sqrt(xdata(i)^2+ydata(i)^2+zdata(i)^2)))-90);
    data.D(i)=wrapTo360(rad2deg(atan2(ydata(i),xdata(i))));
end
% 
% 
subplot(4,6,12)
    first_time=0;
for i=1:length(steps)
    if first_time==0
          hold off
          first_time=1;
    else
          hold on
    end
%        
if data.I(i)<=0
    polarplot(deg2rad(data.D(i)),-data.I(i),'ko-','MarkerSize',5)
elseif data.I(i)>0
    polarplot(deg2rad(data.D(i)),data.I(i),'k.-','MarkerSize',15)
else
    polarplot(NaN,NaN)
end

end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};
h = zeros(2, 1);
h(1) = polarplot(NaN,NaN,'k.','MarkerSize',15);
h(2) = polarplot(NaN,NaN,'ko','MarkerSize',5);
% % 
% % %END SUBTRACTION
% % 



 
% % %PLOT B
xdata=b_data.x_median;
ydata=b_data.y_median;
zdata=b_data.z_median;
mdata=b_data.m_median;
steps=b_data.steps;
data=b_data;
name='e) Component 2 median curve (TC)';

% % %zijderveld
 set(gcf,'Color','w')
 subplot(4,6,[1 2 7 8])

 plot(xdata,-ydata,'k.-','MarkerSize',15)
 hold on
 plot(xdata,-zdata,'ko-','MarkerSize',5)
  title(name)
 box off
% 
% % %set x limits
all_values=[abs(xdata);abs(ydata);abs(zdata)];
max_value=1.2*max(all_values);
 if max_value==0
     max_value=1;
 else
 xlim([-max_value max_value])
 ylim([-max_value max_value])
 end
%  
% % %define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E Am^2/kg'));
text(-max_value,0.95*-max_value,ticksize);

% % 
% % %plot axes
 plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')
% % 
% % %axes labels
text(0.04*max_value,.95*max_value,'Up')
text(-0.1*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.09*max_value,-.93*max_value,'E')
text(-0.97*max_value,0.06*max_value,'S')
text(0.91*max_value,0.06*max_value,'N')
% % 
% % 
% % %remanence plot
subplot(4,6,3)
% subplot(5,7,[3])
plot(steps,mdata./mdata(1),'k.-')
if max(mdata)==0
xlim([0 1.1*max(steps)])
ylim([0 1.1])
else
xlim([0 1.1*max(steps)])
ylim([0 1.1*max(mdata./mdata(1))])
end
grid off
box off
ylabel('M/Mo')
xlabel('step ({\circ}C)')
Mo=strcat('Mo=',num2str(mdata(1),'%.2E Am^2/kg'));
text(0.05*max(steps),1.2,Mo);
% 
% % 
% % %stereonet subplot
% % 
data.I=zeros(height(data),1);
data.D=zeros(height(data),1);
% 
% % %convert to polar coordinates
for i=1:length(steps)
    data.I(i)=-(rad2deg(acos(zdata(i)/sqrt(xdata(i)^2+ydata(i)^2+zdata(i)^2)))-90);
    data.D(i)=wrapTo360(rad2deg(atan2(ydata(i),xdata(i))));
end
% 
% 
% % subplot(6,6,33)
subplot(4,6,9)
    first_time=0;
for i=1:length(steps)
    if first_time==0
          hold off
          first_time=1;
    else
          hold on
    end
%        
if data.I(i)<=0
    polarplot(deg2rad(data.D(i)),-data.I(i),'ko-','MarkerSize',5)
elseif data.I(i)>0
    polarplot(deg2rad(data.D(i)),data.I(i),'k.-','MarkerSize',15)
else
    polarplot(NaN,NaN)
end

end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};
h = zeros(2, 1);
h(1) = polarplot(NaN,NaN,'k.','MarkerSize',15);
h(2) = polarplot(NaN,NaN,'ko','MarkerSize',5);
% % 
% % %END 508 IN SITU
% % 





%PLOT C
steps=c_data.steps;
data=c_data;
 xdata=c_data.x_median;
 ydata=c_data.y_median;
 zdata=c_data.z_median;
 mdata=c_data.m_median;

name=strcat(['g) Component 3 (TC) raw']);



% % %zijderveld
 subplot(4,6,[13 14 19 20])

 plot(xdata,-ydata,'k.-','MarkerSize',15)
 hold on
 plot(xdata,-zdata,'ko-','MarkerSize',5)
  title(name)
 box off

% % %set x limits
all_values=[abs(xdata);abs(ydata);abs(zdata)];
max_value=1.2*max(all_values);
 if max_value==0
     max_value=1;
 else
 xlim([-max_value max_value])
 ylim([-max_value max_value])
 end
%  
% % %define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E Am^2/kg'));
text(-max_value,0.95*-max_value,ticksize);

% % 
% % %plot axes
 plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')
% % 
% % %axes labels
text(0.04*max_value,.95*max_value,'Up')
text(-0.1*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.09*max_value,-.93*max_value,'E')
text(-0.97*max_value,0.06*max_value,'S')
text(0.91*max_value,0.06*max_value,'N')


% % %remanence plot
subplot(4,6,15)
plot(steps,mdata./mdata(1),'k.-')
if max(mdata)==0
xlim([0 1.1*max(steps)])
ylim([0 1.1])
else
xlim([0 1.1*max(steps)])
ylim([0 1.1*max(mdata./mdata(1))])
end
grid off
box off
ylabel('M/Mo')
xlabel('step ({\circ}C)')
Mo=strcat('Mo=',num2str(mdata(1),'%.2E Am^2/kg'));
text(0.05*max(steps),1.2,Mo);


% % %stereonet subplot
data.I=zeros(height(data),1);
data.D=zeros(height(data),1);
% 
% % %convert to polar coordinates
for i=1:length(steps)
    data.I(i)=-(rad2deg(acos(zdata(i)/sqrt(xdata(i)^2+ydata(i)^2+zdata(i)^2)))-90);
    data.D(i)=wrapTo360(rad2deg(atan2(ydata(i),xdata(i))));
end
% 
% 
subplot(4,6,21)
    first_time=0;
for i=1:length(steps)
    if first_time==0
          hold off
          first_time=1;
    else
          hold on
    end
%        
if data.I(i)<=0
    polarplot(deg2rad(data.D(i)),-data.I(i),'ko-','MarkerSize',5)
elseif data.I(i)>0
    polarplot(deg2rad(data.D(i)),data.I(i),'k.-','MarkerSize',15)
else
    polarplot(NaN,NaN)
end

end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};
h = zeros(2, 1);
h(1) = polarplot(NaN,NaN,'k.','MarkerSize',15);
h(2) = polarplot(NaN,NaN,'ko','MarkerSize',5);
% % 
% % 
% % %END SUBTRACTION
% % 







 
% % %PLOT AN SUBTRACTION
an_xsub=an_data.x_median-an_weight*c_data.x_median;
an_ysub=an_data.y_median-an_weight*c_data.y_median;
an_zsub=an_data.z_median-an_weight*c_data.z_median;
% mdata=sqrt(xdata.^2+ydata.^2+zdata.^2);


 
% % %PLOT B SUBTRACTION
b_xsub=b_data.x_median-b_weight*c_data.x_median;
b_ysub=b_data.y_median-b_weight*c_data.y_median;
b_zsub=b_data.z_median-b_weight*c_data.z_median;
% m_bsub=sqrt(xdata.^2+ydata.^2+zdata.^2);


 
% % %PLOT AR SUBTRACTION
ar_xsub=ar_data.x_median-ar_weight*c_data.x_median;
ar_ysub=ar_data.y_median-ar_weight*c_data.y_median;
ar_zsub=ar_data.z_median-ar_weight*c_data.z_median;



%PLOT MIX
steps=c_data.steps;
data=c_data;
mixed_weight=0.5;

  
weight1=0.5;
weight2=0.25;
weight3=0.25;

 xdata=weight1*ar_xsub+weight2*b_xsub+weight3*c_data.x_median;
 ydata=weight1*ar_ysub+weight2*b_ysub+weight3*c_data.y_median;
 zdata=weight1*ar_zsub+weight2*b_zsub+weight3*c_data.z_median;
 
 mdata=sqrt(xdata.^2+ydata.^2+zdata.^2);

name=strcat(['h) Mixed components 1R, 2 and 3 (50:25:25)']);

% % %zijderveld
 set(gcf,'Color','w')
 subplot(4,6,[16 17 22 23])

 plot(xdata,-ydata,'k.-','MarkerSize',15)
 hold on
 plot(xdata,-zdata,'ko-','MarkerSize',5)
  title(name)
 box off
% 
% % %set x limits
all_values=[abs(xdata);abs(ydata);abs(zdata)];
max_value=1.2*max(all_values);
 if max_value==0
     max_value=1;
 else
 xlim([-max_value max_value])
 ylim([-max_value max_value])
 end

% % %define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E Am^2/kg'));
text(-max_value,0.95*-max_value,ticksize);

% % 
% % %plot axes
 plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')

% % 
% % %axes labels
text(0.04*max_value,.95*max_value,'Up')
text(-0.1*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.09*max_value,-.93*max_value,'E')
text(-0.97*max_value,0.06*max_value,'S')
text(0.91*max_value,0.06*max_value,'N')
% % 
% % 
% % %remanence plot
subplot(4,6,18)
plot(steps,mdata./mdata(1),'k.-')
if max(mdata)==0
xlim([0 1.1*max(steps)])
ylim([0 1.1])
else
xlim([0 1.1*max(steps)])
ylim([0 1.1*max(mdata./mdata(1))])
end
grid off
box off
ylabel('M/Mo')
xlabel('step ({\circ}C)')
Mo=strcat('Mo=',num2str(mdata(1),'%.2E Am^2/kg'));
text(0.05*max(steps),1.2,Mo);

% % %stereonet subplot
% % 
data.I=zeros(height(data),1);
data.D=zeros(height(data),1);
% 
% % %convert to polar coordinates
for i=1:length(steps)
    data.I(i)=-(rad2deg(acos(zdata(i)/sqrt(xdata(i)^2+ydata(i)^2+zdata(i)^2)))-90);
    data.D(i)=wrapTo360(rad2deg(atan2(ydata(i),xdata(i))));
end

subplot(4,6,24)
    first_time=0;
for i=1:length(steps)
    if first_time==0
          hold off
          first_time=1;
    else
          hold on
    end
%        
if data.I(i)<=0
    polarplot(deg2rad(data.D(i)),-data.I(i),'ko-','MarkerSize',5)
elseif data.I(i)>0
    polarplot(deg2rad(data.D(i)),data.I(i),'k.-','MarkerSize',15)
else
    polarplot(NaN,NaN)
end

end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};
h = zeros(2, 1);
h(1) = polarplot(NaN,NaN,'k.','MarkerSize',15);
h(2) = polarplot(NaN,NaN,'ko','MarkerSize',5);

% % 
% % 
% % %END 508 IN SITU
% % 



%PCA on mixed component

%define PCA range
first=1;
last=6;


% %calculate mean of each component (in PCA range)
xmean=mean(xdata(first:last));
ymean=mean(ydata(first:last));
zmean=mean(zdata(first:last));

% %uncomment to anchor to origin
% xmean=0;
% ymean=0;
% zmean=0;

%transform coordinates
for i=1:(last-first+1)
xdash(i)=xdata(first+i-1)-xmean;
ydash(i)=ydata(first+i-1)-ymean;
zdash(i)=zdata(first+i-1)-zmean;
end

%create orientation tensor
T=[ sum(xdash.^2)     sum(xdash.*ydash) sum(xdash.*zdash);...
    sum(xdash.*ydash) sum(ydash.^2)     sum(ydash.*zdash);...
    sum(xdash.*zdash) sum(ydash.*zdash) sum(zdash.^2)];

%calculate eigenvectors (NB: columns are the eigenvectors, not rows!)
[V, tau]=eig(T);

%calculate reference vector (determines direction of PCA)
R=[xdash(1)-xdash(end); ydash(1)-ydash(end); zdash(1)-zdash(end)];

%find column for characteristic direction (largest eigenvalue)
[M,I]=max(tau(:));
[I_row, I_col]=ind2sub(size(tau),I);
prince=V(:,I_col);

%find dot product of principal (V1) and reference direction (R)
dot_product=dot(prince,R);

%truncate dot product over -1 to 1
if dot_product<-1
    dot_product=-1;
elseif dot_product>1
    dot_product=1;
end

%give direction sense of V1
if acos(dot_product)>(pi/2)
    PD=-prince;
else
    PD=prince;
end

%calculate declination of V1
if PD(1)<0
    dec=rad2deg(atan(PD(2)/PD(1)))+180
elseif PD(1)>0 && PD(2)<=0
    dec=rad2deg(atan(PD(2)/PD(1)))+360
else
    dec=rad2deg(atan(PD(2)/PD(1)))
end

%calculate inclination of V1
inc=rad2deg(atan(PD(3)/sqrt(PD(1)^2+PD(2)^2)))

%sort eigenvalues
ev=sort([tau(1,1) tau(2,2) tau(3,3)],'descend');

%calculate MAD
MAD=rad2deg(atan(sqrt((ev(2)+ev(3))/ev(1))))


%format
x0=10;
y0=50;
width=1500;
height=900;
set(gcf,'position',[x0,y0,width,height])

%export
set(f1,'Units','points');
pos = get(f1,'Position');
set(f1,'PaperPositionMode','Auto','PaperUnits','points','PaperSize',[pos(3), pos(4)])
print(f1,'export/hunan_curves_b.pdf','-dpdf','-r0')



