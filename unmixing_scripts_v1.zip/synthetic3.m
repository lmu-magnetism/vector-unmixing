close all
clear, clc


%load ref curves
data=readtable('files/ref_curves2.csv','FileType','text','HeaderLines',1,'Delimiter',',');
data.Properties.VariableNames={'steps','ht','lt','sd','md'};


%ENTER DIRECTIONS HERE

%component A
Da=13;    %dec
Ia=77;    %inc
Ashape=data.ht;

%component B
Db=193;   %dec
Ib=-77;     %inc
Bshape=data.ht;

%component C
Dc=138;     %dec
Ic=-46;     %inc
Cshape=data.lt;

%component D
Dd=6;     %dec
Id=4;     %inc
Dshape=data.lt;



%check directions within limits
if Da>360 || Da<-360 || Ia<-90 || Ia>90 
    disp('Warning: directions for component A exceed maximum (-360 > Da > 360, -90 > Ia > 90')
elseif Db>360 || Db<-360 || Ib<-90 || Ib>90 
    disp('Warning: directions for component B exceed limits (-360 > Db > 360, -90 > Ib > 90')
elseif Dc>360 || Dc<-360 || Ic<-90 || Ic>90 
    disp('Warning: directions for component C exceed limits (-360 > Dc > 360, -90 > Ic > 90')
elseif Dd>360 || Dd<-360 || Id<-90 || Id>90 
    disp('Warning: directions for component D exceed limits (-360 > Dd > 360, -90 > Id > 90')
end



%START COMPONENT A

%apply directions to component A and convert steps to Cartesian (XYZ) coordinates
data.xa=zeros(height(data),1);
data.ya=zeros(height(data),1);
data.za=zeros(height(data),1);

for i=1:length(data.steps)
    data.xa(i)=cosd(Ia)*cosd(Da)*Ashape(i);
    data.ya(i)=cosd(Ia)*sind(Da)*Ashape(i);
    data.za(i)=sind(Ia)*Ashape(i);
end

%check data
if sum(Ashape)==0
    disp('Warning: no data entered for component A')
else

end

%END COMPONENT A



%START COMPONENT B

%apply directions to component B and convert steps to Cartesian (XYZ) coordinates
%initialise table
data.xb=zeros(height(data),1);
data.yb=zeros(height(data),1);
data.zb=zeros(height(data),1);

for i=1:length(data.steps)
    data.xb(i)=cosd(Ib)*cosd(Db)*Bshape(i);
    data.yb(i)=cosd(Ib)*sind(Db)*Bshape(i);
    data.zb(i)=sind(Ib)*Bshape(i);
end

%check data
if sum(Bshape)==0
    disp('Warning: no data entered for component B')
else

end
%END COMPONENT B



%START COMPONENT C

%apply directions to component C and convert steps to Cartesian (XYZ) coordinates
data.xc=zeros(height(data),1);
data.yc=zeros(height(data),1);
data.zc=zeros(height(data),1);

for i=1:length(data.steps)
    data.xc(i)=cosd(Ic)*cosd(Dc)*Cshape(i);
    data.yc(i)=cosd(Ic)*sind(Dc)*Cshape(i);
    data.zc(i)=sind(Ic)*Cshape(i);
end


if sum(Cshape)==0
    disp('Warning: no data entered for component C')
else
end

%END COMPONENT C



%START COMPONENT D

%apply directions to component C and convert steps to Cartesian (XYZ) coordinates
data.xd=zeros(height(data),1);
data.yd=zeros(height(data),1);
data.zd=zeros(height(data),1);

for i=1:length(data.steps)
    data.xd(i)=cosd(Id)*cosd(Dd)*Dshape(i);
    data.yd(i)=cosd(Id)*sind(Dd)*Dshape(i);
    data.zd(i)=sind(Id)*Dshape(i);
end


if sum(Dshape)==0
    disp('Warning: no data entered for component D')
else
end

    
%END COMPONENT D




 
% %COMBINE COMPONENTS 1
% %initalise
data.xacd=zeros(height(data),1);
data.yacd=zeros(height(data),1);
data.zacd=zeros(height(data),1);
data.macd=zeros(height(data),1);
data.Iacd=zeros(height(data),1);
data.Dacd=zeros(height(data),1);


% %mix directions
weight=1/3;
for i=1:length(data.steps)
    data.xacd(i)=weight*data.xa(i)+weight*data.xc(i)+weight*data.xd(i);
    data.yacd(i)=weight*data.ya(i)+weight*data.yc(i)+weight*data.yd(i);
    data.zacd(i)=weight*data.za(i)+weight*data.zc(i)+weight*data.zd(i);
    %calculate moment
    data.macd(i)=sqrt(data.xacd(i)^2+data.yacd(i)^2+data.zacd(i)^2);
end

% 
% %plot combined components
% %zijderveld

 f1=figure;
set(gcf,'Color','w')
 subplot(2,6,[1 2 7 8])

 
 plot(data.xacd,-data.yacd,'k.-','MarkerSize',15)
 hold on
 plot(data.xacd,-data.zacd,'ko-','MarkerSize',5)
 title('a) 33% A + 33% C + 33% D')
 box off

% %set x limits
 all_values=[abs(data.xacd);abs(data.yacd);abs(data.zacd)];
 max_value=1.2*max(all_values);
 if max_value==0
     max_value=1;
 else
 xlim([-max_value max_value])
 ylim([-max_value max_value])
 end
 
% %define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E'));
text(-max_value,0.95*-max_value,ticksize);
% 
% %plot axes
 plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')

%axes labels
text(0.04*max_value,.95*max_value,'Up')
text(-0.1*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.08*max_value,-.93*max_value,'E')
text(-0.98*max_value,0.06*max_value,'S')
text(0.92*max_value,0.06*max_value,'N')


%remanence plot

subplot(2,6,3)
plot(data.steps,data.macd./data.macd(1),'k.-')
if max(data.macd)==0
xlim([0 1.1*max(data.steps)])
ylim([0 1.1])
else
xlim([0 1.1*max(data.steps)])
ylim([0 1.1*max(data.macd./data.macd(1))])
end
grid off
box off
ylabel('M/Mo')
xlabel('step ({\circ}C)')
Mo=strcat('Mo=',num2str(data.macd(1),'%.2E'));
text(0.05*max(data.steps),0.095,Mo);


% %stereonet subplot
% %convert to polar coordinates
for i=1:length(data.steps)
    data.Iacd(i)=-(rad2deg(acos(data.zacd(i)/sqrt(data.xacd(i)^2+data.yacd(i)^2+data.zacd(i)^2)))-90);
    data.Dacd(i)=wrapTo360(rad2deg(atan2(data.yacd(i),data.xacd(i))));
end


% subplot(6,6,33)
subplot(2,6,9)
    first_time=0;
for i=1:length(data.steps)
    if first_time==0
          hold off
          first_time=1;
    else
          hold on
    end
       
if data.Iacd(i)<=0
    polarplot(deg2rad(data.Dacd(i)),-data.Iacd(i),'ko-','MarkerSize',5)
elseif data.Iacd(i)>0
    polarplot(deg2rad(data.Dacd(i)),data.Iacd(i),'k.-','MarkerSize',15)
else
    polarplot(NaN,NaN)
end

end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};
h = zeros(2, 1);
h(1) = polarplot(NaN,NaN,'k.','MarkerSize',15);
h(2) = polarplot(NaN,NaN,'ko','MarkerSize',5);


% %END COMBINE COMPONENTS 1



% %COMBINE COMPONENTS 2
% %initalise
data.xbcd=zeros(height(data),1);
data.ybcd=zeros(height(data),1);
data.zbcd=zeros(height(data),1);
data.mbcd=zeros(height(data),1);
data.Ibcd=zeros(height(data),1);
data.Dbcd=zeros(height(data),1);


% %mix directions
for i=1:length(data.steps)
    data.xbcd(i)=data.xb(i)+data.xc(i)+data.xd(i);
    data.ybcd(i)=data.yb(i)+data.yc(i)+data.yd(i);
    data.zbcd(i)=data.zb(i)+data.zc(i)+data.zd(i);
    %calculate moment
    data.mbcd(i)=sqrt(data.xbcd(i)^2+data.ybcd(i)^2+data.zbcd(i)^2);
end

% 
% %plot combined components
% %zijderveld
set(gcf,'Color','w')

 subplot(2,6,[4 5 10 11])
 plot(data.xbcd,-data.ybcd,'k.-','MarkerSize',15)
 hold on
 plot(data.xbcd,-data.zbcd,'ko-','MarkerSize',5)
 title('b) 33% B + 33% C + 33% D')
 box off

% %set x limits
 all_values=[abs(data.xbcd);abs(data.ybcd);abs(data.zbcd)];
 max_value=1.2*max(all_values);
 if max_value==0
     max_value=1;
 else
 xlim([-max_value max_value])
 ylim([-max_value max_value])
 end
 
% %define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E'));
text(-max_value,0.95*-max_value,ticksize);

% %plot axes
 plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')

%axes labels
text(0.04*max_value,.95*max_value,'Up')
text(-0.1*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.08*max_value,-.93*max_value,'E')
text(-0.98*max_value,0.06*max_value,'S')
text(0.92*max_value,0.06*max_value,'N')

% %remanence plot
subplot(2,6,6)
plot(data.steps,data.mbcd./data.mbcd(1),'k.-')
if max(data.mbcd)==0
xlim([0 1.1*max(data.steps)])
ylim([0 1.1])
else
xlim([0 1.1*max(data.steps)])
ylim([0 1.1*max(data.mbcd./data.mbcd(1))])
end
grid off
box off
ylabel('M/Mo')
xlabel('step ({\circ}C)')
Mo=strcat('Mo=',num2str(data.mbcd(1),'%.2E'));
text(0.05*max(data.steps),0.095,Mo);

% %stereonet subplot
% %convert to polar coordinates
for i=1:length(data.steps)
    data.Ibcd(i)=-(rad2deg(acos(data.zbcd(i)/sqrt(data.xbcd(i)^2+data.ybcd(i)^2+data.zbcd(i)^2)))-90);
    data.Dbcd(i)=wrapTo360(rad2deg(atan2(data.ybcd(i),data.xbcd(i))));
end


subplot(2,6,12)
    first_time=0;
for i=1:length(data.steps)
    if first_time==0
          hold off
          first_time=1;
    else
          hold on
    end
       
if data.Ibcd(i)<=0
    polarplot(deg2rad(data.Dbcd(i)),-data.Ibcd(i),'ko-','MarkerSize',5)
elseif data.Ibcd(i)>0
    polarplot(deg2rad(data.Dbcd(i)),data.Ibcd(i),'k.-','MarkerSize',15)
else
    polarplot(NaN,NaN)
end

end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};
h = zeros(2, 1);
h(1) = polarplot(NaN,NaN,'k.','MarkerSize',15);
h(2) = polarplot(NaN,NaN,'ko','MarkerSize',5);


%format
x0=10;
y0=50;
width=1600;
height=450;
set(gcf,'position',[x0,y0,width,height])

%export
set(f1,'Units','Inches');
pos = get(f1,'Position');
set(f1,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(f1,'export/synthetic3.pdf','-dpdf','-r0')
