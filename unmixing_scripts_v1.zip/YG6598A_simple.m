close all
clear, clc

% set(0,'DefaultFigureVisible','off') %don't plot figures
set(0,'DefaultFigureVisible','on') %plot figures


%load input component curves
data=readtable('files/hunan_curves_july2022.csv','FileType','text','HeaderLines',1,'Delimiter',',');
data.Properties.VariableNames={'steps','comp1','comp2','comp3'};


%ENTER RESOLUTION OF 3D MATRIX
resolution=40; %this gets cubed and computationally expensive
%20 is fast to get a good idea, 40 takes 30 seconds on my laptop


%ENTER END MEMBER DIRECTIONS AND SHAPES HERE

%component 1
D1=13;    %dec
I1=77;    %inc
shape1=data.comp1;

%component 2
D2=138;   %dec
I2=-46;     %inc
shape2=data.comp2;

%component 3
D3=6;     %dec
I3=4;     %inc
shape3=data.comp3;




%choose specimen
filename='YG6598A.rs3';
mass=28.2074/1000; %kg

%example files: YG2965B, YG4532A, YG5825A (need to reverse component 1), YG6598A, YG6631A  
%specimen masses:  26.8818, 28.3291, 21.1255, 28.2074, 27.4863

for ilist=1

    %read file
     fid=fopen(strcat('files\hunan_specimens\',filename));
    C=textscan(fid,'%s %d %f %f %f %f %f %f %f %f','headerlines',3);
    fclose(fid);
 
    %get relevant data
    steps=C{2};
    M=C{3}*11e-6/mass;
    Ds=C{8};
    Is=C{9};
    
    %convert data to tilt-corrected (cartestion) coordinates
    for j=1:length(steps)
    data2.steps(j,1)=steps(j);    
    data2.xmix(j,1)=M(j)*cosd(Is(j))*cosd(Ds(j));
    data2.ymix(j,1)=M(j)*cosd(Is(j))*sind(Ds(j));
    data2.zmix(j,1)=M(j)*sind(Is(j));
    data2.mmix(j,1)=M(j);
    end 


%check directions within limits
if D1>360 || D1<-360 || I1<-90 || I1>90 
    disp('Warning: directions for component 1 exceed maximum (-360 > D1 > 360, -90 > I1 > 90')
elseif D2>360 || D2<-360 || I2<-90 || I2>90 
    disp('Warning: directions for component 2 exceed limits (-360 > D2 > 360, -90 > I2 > 90')
elseif D3>360 || D3<-360 || I3<-90 || I3>90 
    disp('Warning: directions for component 3 exceed limits (-360 > D3 > 360, -90 > I3 > 90')
end



%START COMPONENT 1

%apply directions to component A and convert steps to Cartesian (XYZ) coordinates
data.x1=zeros(height(data),1);
data.y1=zeros(height(data),1);
data.z1=zeros(height(data),1);

for i=1:length(data.steps)
    data.x1(i)=cosd(I1)*cosd(D1)*shape1(i);
    data.y1(i)=cosd(I1)*sind(D1)*shape1(i);
    data.z1(i)=sind(I1)*shape1(i);
end

%check data
if sum(shape1)==0
    disp('Warning: no data entered for component 1')
end



    %START COMPONENT 2

%apply directions to component 2 and convert steps to Cartesian (XYZ) coordinates
%initialise table
data.x2=zeros(height(data),1);
data.y2=zeros(height(data),1);
data.z2=zeros(height(data),1);

for i=1:length(data.steps)
    data.x2(i)=cosd(I2)*cosd(D2)*shape2(i);
    data.y2(i)=cosd(I2)*sind(D2)*shape2(i);
    data.z2(i)=sind(I2)*shape2(i);
end

%check data
if sum(shape2)==0
    disp('Warning: no data entered for component 2')
end
    
    
    

%START COMPONENT 3

%apply directions to component 3 and convert steps to Cartesian (XYZ) coordinates
data.x3=zeros(height(data),1);
data.y3=zeros(height(data),1);
data.z3=zeros(height(data),1);

for i=1:length(data.steps)
    data.x3(i)=cosd(I3)*cosd(D3)*shape3(i);
    data.y3(i)=cosd(I3)*sind(D3)*shape3(i);
    data.z3(i)=sind(I3)*shape3(i);
end


if sum(shape3)==0
    disp('Warning: no data entered for component 3')
end


 
% %PLOT INPUT COMPONENT
% %zijderveld
f1=figure;
set(gcf,'Color','w')
subplot(5,6,[1 2 7 8])

 plot(data2.xmix,-data2.ymix,'k.-','MarkerSize',15)
 hold on
 plot(data2.xmix,-data2.zmix,'ko-','MarkerSize',5)
 words=strcat('a) Input file (',string(filename),')');
 title(words)
 box off

% %set x limits
 all_values=[abs(data2.xmix);abs(data2.ymix);abs(data2.zmix)];
 max_value=1.2*max(all_values);
 if max_value==0
     max_value=1;
 else
 xlim([-max_value max_value])
 ylim([-max_value max_value])
 end
 
% %define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E Am^2/kg'));
text(-max_value,0.95*-max_value,ticksize);

% %plot axes
 plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')

% %axes labels
text(0.04*max_value,.95*max_value,'Up')
text(-0.12*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.1*max_value,-.93*max_value,'E')
text(-0.97*max_value,0.07*max_value,'S')
text(0.91*max_value,0.07*max_value,'N')


% %remanence plot

subplot(5,6,3)
plot(data2.steps,data2.mmix./data2.mmix(1),'k.-')
if max(data2.mmix)==0
xlim([0 1.1*max(data2.steps)])
ylim([0 1.1])
else
xlim([0 1.1*max(data2.steps)])
ylim([0 1.1*max(data2.mmix./data2.mmix(1))])
end
grid off
box off
ylabel('M/Mo')
xlabel('step ({\circ}C)')
Mo=strcat('Mo=',num2str(data2.mmix(1),'%.2E Am^2/kg'));
text(10,1.2,Mo);


% %stereonet subplot
% %convert to polar coordinates
for i=1:length(data2.steps)
    data2.Imix(i)=-(rad2deg(acos(data2.zmix(i)/sqrt(data2.xmix(i)^2+data2.ymix(i)^2+data2.zmix(i)^2)))-90);
    data2.Dmix(i)=wrapTo360(rad2deg(atan2(data2.ymix(i),data2.xmix(i))));
end


% subplot(6,6,33)
subplot(5,6,9)
    first_time=0;
for i=1:length(data2.steps)
    if first_time==0
          hold off
          first_time=1;
    else
          hold on
    end
       
if data2.Imix(i)<=0
    polarplot(deg2rad(data2.Dmix(i)),-data2.Imix(i),'ko-','MarkerSize',5)
elseif data2.Imix(i)>0
    polarplot(deg2rad(data2.Dmix(i)),data2.Imix(i),'k.-','MarkerSize',15)
else
    polarplot(NaN,NaN)
end

end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};

% 
% 
% %END plot input
% 




%make 3D matrix
points=resolution+1;
max_weight=2;

residual=zeros(points,points,points);
for i=1:points;
    for j=1:points;
        for k=1:points;
        array.x=max_weight/resolution*(i-1)*data.x1+max_weight/resolution*(j-1)*data.x2+max_weight/resolution*(k-1)*data.x3;
        array.y=max_weight/resolution*(i-1)*data.y1+max_weight/resolution*(j-1)*data.y2+max_weight/resolution*(k-1)*data.y3;
        array.z=max_weight/resolution*(i-1)*data.z1+max_weight/resolution*(j-1)*data.z2+max_weight/resolution*(k-1)*data.z3;    
        
        subtract.x=data2.xmix-array.x;
        subtract.y=data2.ymix-array.y;
        subtract.z=data2.zmix-array.z;
        subtract.m=sqrt(subtract.x.^2+subtract.y.^2+subtract.z.^2);
        
        residual(i,j,k)=sum(subtract.m);
        end
    end
end


% %plot 3D scatterplot
subplot(5,6,[13 15 19 21])
 [X,Y,Z] = ndgrid(1:size(residual,1), 1:size(residual,2), 1:size(residual,3));
pointsize = 1;
scatter3(X(:), Y(:), Z(:), pointsize, residual(:));
 
xlabel('Comp. 1 weight (%)','Rotation',14)
ylabel('Comp. 2 weight (%)','Rotation',-26)
zlabel('Comp. 3 weight (%)')

xlim([1 points])
ylim([1 points])
zlim([1 points])

xticks([1:resolution/5:points])
yticks([1:resolution/5:points])
zticks([1:resolution/5:points])

xticklabels([0:20:100]*max_weight)
yticklabels([0:20:100]*max_weight)
zticklabels([0:20:100]*max_weight)


title('c) Unmixing residuals for median solution')
 c = colorbar;
 c.Label.String = 'Sum of residuals';
 set(gcf,'Color','w')
 set(colorbar,'visible','off')
 
 
 [v,loc]=min(residual(:));
 [ii,jj,k] = ind2sub(size(residual),loc);
weighting1=max_weight/resolution*(ii-1);
weighting2=max_weight/resolution*(jj-1);
weighting3=max_weight/resolution*(k-1);
smallest=min(residual(:));
largest=max(residual(:));

grid on
 caxis([smallest largest])


 %isosurfaces
subplot(5,6,[16 18 22 24])
%switch X and Y axes to match ndgrid convention
residual = permute(residual,[2 1 3]);
hold on
limit5=0.05; %bounding isosurface 
isosurface(residual,limit5*(largest-smallest)+smallest);


xlabel('Comp. 1 weight (%)','Rotation',14)
ylabel('Comp. 2 weight (%)','Rotation',-26)
zlabel('Comp. 3 weight (%)')

xlim([1 points])
ylim([1 points])
zlim([1 points])

xticks([1:resolution/5:points])
yticks([1:resolution/5:points])
zticks([1:resolution/5:points])

xticklabels([0:20:100]*max_weight)
yticklabels([0:20:100]*max_weight)
zticklabels([0:20:100]*max_weight)



grid on

title('d) Unmixing residuals for median solution (5% isosurface)')
  c = colorbar;
  c.Label.String = 'Sum of residuals (Am^2/kg)';
 set(gcf,'Color','w')
 caxis([smallest largest])
view(3);
camlight;
lighting gouraud;

result=sum(sum(sum(residual<=(0.05*largest))));
precision=(1-result/resolution^3)*100;


%best fitting component
data2.xfit=weighting1*data.x1+weighting2*data.x2+weighting3*data.x3;
data2.yfit=weighting1*data.y1+weighting2*data.y2+weighting3*data.y3;
data2.zfit=weighting1*data.z1+weighting2*data.z2+weighting3*data.z3;
data2.mfit=sqrt(data2.xfit.^2+data2.yfit.^2+data2.zfit.^2);


% %PLOT OUTPUT COMPONENT
% %zijderveld

subplot(5,6,[4 5 10 11])

 plot(data2.xfit,-data2.yfit,'k.-','MarkerSize',15)
 hold on
 plot(data2.xfit,-data2.zfit,'ko-','MarkerSize',5)
 title('b) Output (best fitting combination)')
 box off

% %set x limits
 all_values=[abs(data2.xfit);abs(data2.yfit);abs(data2.zfit)];
 max_value=1.2*max(all_values);
 if max_value==0
     max_value=1;
 else
 xlim([-max_value max_value])
 ylim([-max_value max_value])
 end
 
% %define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E Am^2/kg'));
text(-max_value,0.95*-max_value,ticksize);
% 
% %plot axes
 plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')
% 
% %axes labels
text(0.04*max_value,.95*max_value,'Up')
text(-0.12*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.1*max_value,-.93*max_value,'E')
text(-0.97*max_value,0.07*max_value,'S')
text(0.91*max_value,0.07*max_value,'N')

 
% %remanence plot

subplot(5,6,6)
plot(data2.steps,data2.mfit./data2.mfit(1),'k.-')
if max(data2.mfit)==0
xlim([0 1.1*max(data2.steps)])
ylim([0 1.1])
else
xlim([0 1.1*max(data2.steps)])
ylim([0 1.1*max(data2.mfit./data2.mfit(1))])
end
grid off
box off
ylabel('M/Mo')
xlabel('step ({\circ}C)')
Mo=strcat('Mo=',num2str(data2.mfit(1),'%.2E Am^2/kg'));
text(10,1.2,Mo);


% %stereonet subplot
% %convert to polar coordinates
for i=1:length(data2.steps)
    data2.Ifit(i)=-(rad2deg(acos(data2.zfit(i)/sqrt(data2.xfit(i)^2+data2.yfit(i)^2+data2.zfit(i)^2)))-90);
    data2.Dfit(i)=wrapTo360(rad2deg(atan2(data2.yfit(i),data2.xfit(i))));
end


% subplot(6,6,33)
subplot(5,6,12)
    first_time=0;
for i=1:length(data2.steps)
    if first_time==0
          hold off
          first_time=1;
    else
          hold on
    end
       
if data2.Ifit(i)<=0
    polarplot(deg2rad(data2.Dfit(i)),-data2.Ifit(i),'ko-','MarkerSize',5)
elseif data2.Ifit(i)>0
    polarplot(deg2rad(data2.Dfit(i)),data2.Ifit(i),'k.-','MarkerSize',15)
else
    polarplot(NaN,NaN)
end

end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};
h = zeros(2, 1);
h(1) = polarplot(NaN,NaN,'k.','MarkerSize',15);
h(2) = polarplot(NaN,NaN,'ko','MarkerSize',5);


end
    


x0=10;
y0=-50;
width=1400;
height=1050;
set(gcf,'position',[x0,y0,width,height])

    
% 
% 
% %END plot input
% 

%average cosine similarity
for i=1:length(data2.xmix)
data2.cossim(i)=(data2.xmix(i)*data2.xfit(i)+...
    data2.ymix(i)*data2.yfit(i)+...
    data2.zmix(i)*data2.zfit(i))/...
    (sqrt(data2.xmix(i)^2+data2.ymix(i)^2+data2.zmix(i)^2)*...
    sqrt(data2.xfit(i)^2+data2.yfit(i)^2+data2.zfit(i)^2));
end

acs=mean(data2.cossim);



% figure;
subplot(5,6,[25 30])
axis off
box off
zero_fit=sum(data2.mmix);
goodness=(zero_fit-smallest)/zero_fit*100;

hshift=0.05;

words=['Component 1 median:'];
text(0.36-hshift,.7,words)
words=['Component 2 median:'];
text(0.36-hshift,0.5,words)
words=['Component 3 median:'];
text(0.36-hshift,0.3,words)


words=['Best-fit weighting [%]'];
text(0.54-hshift,0.9,words)
words=[num2str(weighting1*100,'%.1f')];
text(0.55-hshift,.7,words)
words=[num2str(weighting2*100,'%.1f')];
text(0.55-hshift,0.5,words)
words=[num2str(weighting3*100,'%.1f')];
text(0.55-hshift,0.3,words)


words=['Parameters:'];
text(0.0-hshift,1,words)
words=['Resolution of 3D matrix'];
text(0.01-hshift,0.8,words)
words=[num2str(resolution) 'x' num2str(resolution) 'x' num2str(resolution)];
text(0.16-hshift,0.8,words)
words=['# of simulations'];
text(0.01-hshift,0.6,words)
words=['1 (simple)'];
text(0.16-hshift,0.6,words)
words=['Average cosine similarity'];
text(0.01-hshift,0.4,words)
words=[num2str(acs,'%.3f')];
text(0.16-hshift,0.4,words)
words=['Goodness of fit [%]'];
text(0.01-hshift,0.2,words)
words=[num2str(goodness,'%.1f')];
text(0.16-hshift,0.2,words)


words=['Estimated NRM [Am^2/kg]'];
text(0.7-hshift,0.9,words)
words=[num2str(weighting1*data.comp1(1),'%.2s')];
text(0.71-hshift,.7,words)
words=[num2str(weighting2*data.comp2(1),'%.2s')];
text(0.71-hshift,.5,words)
words=[num2str(weighting3*data.comp3(1),'%.2s')];
text(0.71-hshift,0.3,words)

total_NRM=sum(weighting1*data.comp1(1)+weighting2*data.comp2(1)+weighting3*data.comp3(1));

words=['Proportion of total NRM [%]'];
text(0.91-hshift,0.9,words)
words=[num2str(weighting1*data.comp1(1)/total_NRM*100,'%.1f')];
text(0.92-hshift,.7,words)
words=[num2str(weighting2*data.comp2(1)/total_NRM*100,'%.1f')];
text(0.92-hshift,.5,words)
words=[num2str(weighting3*data.comp3(1)/total_NRM*100,'%.1f')];
text(0.92-hshift,0.3,words)




%export
set(f1,'Units','Inches');
pos = get(f1,'Position');
set(f1,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
set(gcf,'renderer','painters');  
print(f1,'export/YG6598A_simple.pdf','-dpdf','-r0')



