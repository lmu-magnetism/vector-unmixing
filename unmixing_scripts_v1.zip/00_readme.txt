These are the MATLAB scripts used to produce the figures from GJI article:
Vector unmixing of multicomponent palaeomagnetic data
https://doi.org/10.1093/gji/ggac505

Version 1 (v1) uploaded on 29 January 2023.

If you have any questions or queries, please don't hesitate to contact me:
j.tonti@lmu.de



Descriptions of scripts:

Figure 1: hem_curves.m
Plots reference curves from literature.

Figure 2: synthetic1a.m and synthetic1b.m
Generates synthetic curves for components A-D, and mixes 2 components in 1:1 ratios (A+C, A+D, B+C, B+D)

Figure 3: synthetic2.m
Mixes 2 components (A and C) in different ratios and performs PCA on the results.

Figure 4: unmix2.m
Inverse modelling of combined A+C result.

Figure 5: synthetic3.m
Mixes 3 components in 1:1:1 ratios (A+C+D and B+C+D).

Figure 6: unmix3.m
Inverse modelling of combined A+C+D result.

Figure 7: k_curves.m
Plots specimen data and median curves for Cretaceous specimens from Gilder and Courtillot study.

Figure 8: j2_subtractions.m
Plots median curves for Jurassic sites from G&C (with and without component subtraction).

Figure 9: j2_variable.m
Plots the result of variable subtractions from Jurassic sites.

Figure 10: modelling_5072_simple.m
Inverse modelling of specimen 5072 from G&C (without Monte Carlo simulations).

Figure 11: hunan_curves_a.m and hunan_curves_b.m
Plots median curves from Yangjiaping with and without component subtractions, as well as example of mixing three components (1R, 2 and 3).

Figure 12: YG4532A_simple.m
Inverse modelling of specimen YG4532A (without Monte Carlo simulations).

Figure 13: YG6598A_simple.m
Inverse modelling of specimen YG6598A (without Monte Carlo simulations).

Figure 14: YG5825A_simple.m
Inverse modelling of specimen YG5825A (without Monte Carlo simulations).



Supplementary figures:

Figure A1: j2_curves_a.m and j2_curves_b.m
Plots specimen data from Middle Jurassic sites from G&C

Figure A2: j2_endmembers.m
Plots specimen data from Middle Jurassic site C508 from G&C after component subtraction. Also plots C508 median curve (raw) and C509 median curve (idealised)

Figure A3: hunan_specimens_a.m, hunan_specimens_b.m, hunan_specimens_c.m, hunan_specimens_d.m
Plots raw specimen data from Yangjiaping end-members (components 1-3)

Figure A4: hunan_variable.m
Plots variable subtractions of component 3 from components 1N, 1R and 2 (Yangajiaping)

Figure A5: hunan_totals.m
Plots total moments of end-member profiles after variable subtraction (Yangajiaping)

Figure A6: hunan_endmembers.m
Plots idealised median curves for each component from Yangajiaping.

Figure A7: YG2965B_simple.m
Inverse modelling of specimen YG2965B (without Monte Carlo simulations).

Figure A8: YG6631A_simple.m
Inverse modelling of specimen YG6631A (without Monte Carlo simulations).


Additional script: subplot_tight.m
For better control of subplot formatting (I didn't write this).
