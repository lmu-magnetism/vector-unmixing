set(0,'DefaultFigureVisible','on') %plot figures

close all
clear, clc


%get cretaceous (TC) curves
k_data=readtable('files/cretaceous_curves_multi_TC.csv','FileType','text','HeaderLines',1,'Delimiter',',');
k_data.Properties.VariableNames={'steps','x_lq','x_median','x_uq','y_lq','y_median','y_uq','z_lq','z_median','z_uq'};
k_data.m_median=sqrt(k_data.x_median.^2+k_data.y_median.^2+k_data.z_median.^2);


%get cretaceous (IS) curves
k_data2=readtable('files/cretaceous_curves_multi_IS.csv','FileType','text','HeaderLines',1,'Delimiter',',');
k_data2.Properties.VariableNames={'steps','x_lq','x_median','x_uq','y_lq','y_median','y_uq','z_lq','z_median','z_uq'};
k_data2.m_median=sqrt(k_data2.x_median.^2+k_data2.y_median.^2+k_data2.z_median.^2);


%Cretaceous direction from all sites (TC)
I=53.3;
D=17.5;


%apply directions to median curve
k_data3.x_median=k_data.m_median*cosd(I)*cosd(D);
k_data3.y_median=k_data.m_median*cosd(I)*sind(D);
k_data3.z_median=k_data.m_median*sind(I);
k_data3.m_median=sqrt(k_data3.x_median.^2+k_data3.y_median.^2+k_data3.z_median.^2);


%get normal (508) curves
n_data=readtable('files/c508J2N_curves_IS.csv','FileType','text','HeaderLines',1,'Delimiter',',');
n_data.Properties.VariableNames={'steps','x_lq','x_median','x_uq','y_lq','y_median','y_uq','z_lq','z_median','z_uq'};
n_data.m_median=sqrt(n_data.x_median.^2+n_data.y_median.^2+n_data.z_median.^2);

%get reverse (509) curves
r_data=readtable('files/c509J2R_curves_IS.csv','FileType','text','HeaderLines',1,'Delimiter',',');
r_data.Properties.VariableNames={'steps','x_lq','x_median','x_uq','y_lq','y_median','y_uq','z_lq','z_median','z_uq'};
r_data.m_median=sqrt(r_data.x_median.^2+r_data.y_median.^2+r_data.z_median.^2);


%interpolate cretaceous data to jurassic steps
k_interp.x_median=interp1(k_data.steps,k_data3.x_median,n_data.steps);
k_interp.y_median=interp1(k_data.steps,k_data3.y_median,n_data.steps);
k_interp.z_median=interp1(k_data.steps,k_data3.z_median,n_data.steps);
k_interp.m_median=interp1(k_data.steps,k_data3.m_median,n_data.steps);



resolution=200;
MAD=zeros(resolution,1);
flatness=zeros(resolution,1);
weight=zeros(resolution,1);
R_squared=zeros(resolution,1);


xdash=zeros(height(n_data),1);
ydash=zeros(height(n_data),1);
zdash=zeros(height(n_data),1);
dec=zeros(height(n_data),1);
inc=zeros(height(n_data),1);
R_value=zeros(height(n_data),1);
kappa=zeros(height(n_data),1);


for j=1:(resolution+1)
%assign subtraction weight (of Cretaceous direction)
weight(j)=(j-1)/resolution;
xdata=n_data.x_median-weight(j)*k_interp.x_median;
ydata=n_data.y_median-weight(j)*k_interp.y_median;
zdata=n_data.z_median-weight(j)*k_interp.z_median;
mdata=sqrt(xdata.^2+ydata.^2+zdata.^2);

%define PCA range
first=15;
last=length(mdata);

flatness(j)=std(mdata(1:8));

% %calculate mean of each component (in PCA range)
% xmean=mean(xdata(first:last));
% ymean=mean(ydata(first:last));
% zmean=mean(zdata(first:last));

% %uncomment to anchor to origin
xmean=0;
ymean=0;
zmean=0;

%transform coordinates
for i=1:(last-first)
xdash(i)=xdata(first+i-1)-xmean;
ydash(i)=ydata(first+i-1)-ymean;
zdash(i)=zdata(first+i-1)-zmean;
end

%create orientation tensor
T=[ sum(xdash.^2)     sum(xdash.*ydash) sum(xdash.*zdash);...
    sum(xdash.*ydash) sum(ydash.^2)     sum(ydash.*zdash);...
    sum(xdash.*zdash) sum(ydash.*zdash) sum(zdash.^2)];

%calculate eigenvectors (NB: columns are the eigenvectors, not rows!)
[V, tau]=eig(T);

%calculate reference vector (determines direction of PCA)
R=[xdash(1)-xdash(end); ydash(1)-ydash(end); zdash(1)-zdash(end)];

%find column for characteristic direction (largest eigenvalue)
[M,I]=max(tau(:));
[I_row, I_col]=ind2sub(size(tau),I);
prince=V(:,I_col);

%find dot product of principal (V1) and reference direction (R)
dot_product=dot(prince,R);

%truncate dot product over -1 to 1
if dot_product<-1
    dot_product=-1;
elseif dot_product>1
    dot_product=1;
end

%give direction sense of V1
if acos(dot_product)>(pi/2)
    PD=-prince;
else
    PD=prince;
end

%calculate declination of V1
if PD(1)<0
    dec(j)=rad2deg(atan(PD(2)/PD(1)))+180;
elseif PD(1)>0 && PD(2)<=0
    dec(j)=rad2deg(atan(PD(2)/PD(1)))+360;
else
    dec(j)=rad2deg(atan(PD(2)/PD(1)));
end

%calculate inclination of V1
inc(j)=rad2deg(atan(PD(3)/sqrt(PD(1)^2+PD(2)^2)));

%sort eigenvalues
ev=sort([tau(1,1) tau(2,2) tau(3,3)],'descend');

%calculate MAD
MAD(j)=rad2deg(atan(sqrt((ev(2)+ev(3))/ev(1))));


%calculate R
tail=1;
range=length(mdata)-tail;
first_point=1;
xdatadash=xdata(first_point:end-tail)./mdata(first_point:end-tail);
ydatadash=ydata(first_point:end-tail)./mdata(first_point:end-tail);
zdatadash=zdata(first_point:end-tail)./mdata(first_point:end-tail);
R_squared(j)=sum(xdatadash)^2+sum(ydatadash)^2+sum(zdatadash)^2;
R_value(j)=sqrt(R_squared(j))/1;
kappa(j)=(range-first_point+1-1)/(range-first_point+1-R_value(j));


end

[Mopt,Iopt]=max(kappa);
%[Mopt,Iopt]=min(flatness);


f1=figure;
set(gcf,'Color','w')
subplot(1,2,1)
title('a) Variable subtraction of C508 overprint')
yyaxis left
plot(weight,kappa)
xticks([0:0.2:1])
xticklabels([0:20:100])
xlabel('% of Cretaceous curve subtracted')
ylabel(['\kappa (precision parameter) after subtraction'])
hold on
plot([weight(Iopt) weight(Iopt)],[0 100],'k')
ylim([0 100])
yyaxis right
plot(weight,flatness)
ylim([0 10e-3])
ylabel(['\sigma_{flat} after subtraction (A/m)'])

weight=weight(Iopt); %amount of cretaceous component to subtract


% % %PLOT 509 SUBTRACTION
xdata=n_data.x_median-weight*k_interp.x_median;
ydata=n_data.y_median-weight*k_interp.y_median;
zdata=n_data.z_median-weight*k_interp.z_median;
mdata=sqrt(xdata.^2+ydata.^2+zdata.^2);

steps=n_data.steps;
data=n_data;
name=strcat('C508J2N (IS) minus ',{' '},num2str(weight*100),'% of Cretaceous (IS) curve');








for j=1:(resolution+1)
%assign subtraction weight (of Cretaceous direction)
weight(j)=(j-1)/resolution;
xdata=r_data.x_median-weight(j)*k_interp.x_median;
ydata=r_data.y_median-weight(j)*k_interp.y_median;
zdata=r_data.z_median-weight(j)*k_interp.z_median;
mdata=sqrt(xdata.^2+ydata.^2+zdata.^2);

%define PCA range
first=1;
last=length(mdata);

flatness(j)=std(mdata(1:8));

% %calculate mean of each component (in PCA range)
% xmean=mean(xdata(first:last));
% ymean=mean(ydata(first:last));
% zmean=mean(zdata(first:last));

% %uncomment to anchor to origin
xmean=0;
ymean=0;
zmean=0;

%transform coordinates
for i=1:(last-first)
xdash(i)=xdata(first+i-1)-xmean;
ydash(i)=ydata(first+i-1)-ymean;
zdash(i)=zdata(first+i-1)-zmean;
end

%create orientation tensor
T=[ sum(xdash.^2)     sum(xdash.*ydash) sum(xdash.*zdash);...
    sum(xdash.*ydash) sum(ydash.^2)     sum(ydash.*zdash);...
    sum(xdash.*zdash) sum(ydash.*zdash) sum(zdash.^2)];

%calculate eigenvectors (NB: columns are the eigenvectors, not rows!)
[V, tau]=eig(T);

%calculate reference vector (determines direction of PCA)
R=[xdash(1)-xdash(end); ydash(1)-ydash(end); zdash(1)-zdash(end)];

%find column for characteristic direction (largest eigenvalue)
[M,I]=max(tau(:));
[I_row, I_col]=ind2sub(size(tau),I);
prince=V(:,I_col);

%find dot product of principal (V1) and reference direction (R)
dot_product=dot(prince,R);

%truncate dot product over -1 to 1
if dot_product<-1
    dot_product=-1;
elseif dot_product>1
    dot_product=1;
end

%give direction sense of V1
if acos(dot_product)>(pi/2)
    PD=-prince;
else
    PD=prince;
end

%calculate declination of V1
if PD(1)<0
    dec(j)=rad2deg(atan(PD(2)/PD(1)))+180;
elseif PD(1)>0 && PD(2)<=0
    dec(j)=rad2deg(atan(PD(2)/PD(1)))+360;
else
    dec(j)=rad2deg(atan(PD(2)/PD(1)));
end

%calculate inclination of V1
inc(j)=rad2deg(atan(PD(3)/sqrt(PD(1)^2+PD(2)^2)));

%sort eigenvalues
ev=sort([tau(1,1) tau(2,2) tau(3,3)],'descend');

%calculate MAD
MAD(j)=rad2deg(atan(sqrt((ev(2)+ev(3))/ev(1))));

%calculate R
tail=3;
steps=length(mdata)-tail;
xdatadash=xdata(1:end-tail)./mdata(1:end-tail);
ydatadash=ydata(1:end-tail)./mdata(1:end-tail);
zdatadash=zdata(1:end-tail)./mdata(1:end-tail);
R_squared(j)=sum(xdatadash)^2+sum(ydatadash)^2+sum(zdatadash)^2;
R_value(j)=sqrt(R_squared(j))/1;
kappa(j)=(steps-1)/(steps-R_value(j));

end

% [Mopt,Iopt]=max(kappa);
[Mopt,Iopt]=min(flatness);

subplot(1,2,2)
title('b) Variable subtraction of C509 overprint')
yyaxis left
plot(weight,kappa)
xlabel('% of Cretaceous curve subtracted')
xticks([0:0.2:1])
xticklabels([0:20:100])
ylabel(['\kappa (precision parameter) after subtraction'])
hold on
ylim([0 100])
yyaxis right
plot(weight,flatness)
plot([weight(Iopt) weight(Iopt)],[0 100],'k')
ylim([0 10e-3])
ylabel(['\sigma_{flat} after subtraction (A/m)'])
 

weight=weight(Iopt); %amount of cretaceous component to subtract


% % %PLOT 509 SUBTRACTION
xdata=n_data.x_median-weight*k_interp.x_median;
ydata=n_data.y_median-weight*k_interp.y_median;
zdata=n_data.z_median-weight*k_interp.z_median;
mdata=sqrt(xdata.^2+ydata.^2+zdata.^2);

steps=n_data.steps;
data=n_data;
name=strcat('C508J2N (IS) minus ',{' '},num2str(weight*100),'% of Cretaceous (IS) curve');


x0=10;
y0=50;
width=1200;
height=350;
set(gcf,'position',[x0,y0,width,height])




set(f1,'Units','Inches');
pos = get(f1,'Position');
set(f1,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(f1,'export/j2_variable.pdf','-dpdf','-r0')

