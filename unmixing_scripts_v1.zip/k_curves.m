close all
clear, clc, clf

%change directory
cd 'files\c526k_c529k'

%get file list
list=cellstr(ls('*.pmd'));

%read files
for ilist=1:length(list)

    fid=fopen(string(list(ilist)));
    C=textscan(fid,'%s %f %f %f %f %f %f %f %f %f %f','headerlines',3);
    fclose(fid);
 
%       %get relevant data
    steps=C{1};
    M=C{5};
     Dg=C{6};
     Ig=C{7};
     Ds=C{8};
     Is=C{9};
    
     
     %choose coordinate system
     %geo
%      I=Ig;
%      D=Dg;

     %tilt-corrected
      I=Is;
      D=Ds;
      
    for j=1:length(steps)
    Marray(ilist,j)=M(j);    
    Xarray(ilist,j)=M(j)*cosd(I(j))*cosd(D(j));
    Yarray(ilist,j)=M(j)*cosd(I(j))*sind(D(j));
    Zarray(ilist,j)=M(j)*sind(I(j));
    end

    
end

cd '../../'

steps=[0,100,200,300,400,500,565,605,627,641,652,662,670,677,684,691,698,705];



% %find median values
Mquantiles(1,:)=quantile(Marray,0.25);
Mquantiles(2,:)=quantile(Marray,0.50);
Mquantiles(3,:)=quantile(Marray,0.75);

Xquantiles(1,:)=quantile(Xarray,0.25);
Xquantiles(2,:)=quantile(Xarray,0.50);
Xquantiles(3,:)=quantile(Xarray,0.75);

Yquantiles(1,:)=quantile(Yarray,0.25);
Yquantiles(2,:)=quantile(Yarray,0.50);
Yquantiles(3,:)=quantile(Yarray,0.75);

Zquantiles(1,:)=quantile(Zarray,0.25);
Zquantiles(2,:)=quantile(Zarray,0.50);
Zquantiles(3,:)=quantile(Zarray,0.75);



% f1=figure;
subplot(2,3,2)
set(gcf,'Color','w')
xlabel('Temperature step')
ylabel('Total moment (A/m)')
title({'a) C526 and C529 specimen data (tilt-corrected)',''})

grey=[180 180 180]/255;

for i=1:size(Yarray,1)
hold on
plot(steps,Yarray(i,:),'Color',grey)
end

xlabel(['Temperature step (' char(176) 'C)'])
ylabel('Y moment (A/m)')
xlim([0 750])

hold on
plot(steps,Yquantiles(1,:),'go-')
hold on
plot(steps,Yquantiles(2,:),'ko-')
hold on
plot(steps,Yquantiles(3,:),'ro-')






subplot(2,3,1)

for i=1:size(Xarray,1)
hold on
plot(steps,Xarray(i,:),'Color',grey)
end

ylabel('X moment (A/m)')
xlim([0 750])
hold on
plot(steps,Xquantiles(1,:),'go-')
hold on
plot(steps,Xquantiles(2,:),'ko-')
hold on
plot(steps,Xquantiles(3,:),'ro-')


subplot(2,3,3)

for i=1:size(Zarray,1)
hold on
plot(steps,Zarray(i,:),'Color',grey)
end

set(gcf,'Color','w')
ylabel('Z moment (A/m)')
xlim([0 750])
plot(steps,Zquantiles(1,:),'go-')
hold on
plot(steps,Zquantiles(2,:),'ko-')
hold on
plot(steps,Zquantiles(3,:),'ro-')



h = zeros(4, 1);
h(4) = plot(NaN,NaN,'Color',grey);
h(3) = plot(NaN,NaN,'go-');
h(2) = plot(NaN,NaN,'ko-');
h(1) = plot(NaN,NaN,'ro-');
legend(h, 'UQ','median','LQ','specimen data','Location','northeast');







% % %PLOT CRETAECOUS TC
xdata=Xquantiles(2,:);
ydata=Yquantiles(2,:);
zdata=Zquantiles(2,:);
mdata=Mquantiles(2,:);
name='b) Cretaceous (median curve) TC';

% % %zijderveld
 set(gcf,'Color','w')
 subplot(4,6,[13 14 19 20])
 
 plot(xdata,-ydata,'k.-','MarkerSize',15)
 hold on
 plot(xdata,-zdata,'ko-','MarkerSize',5)
  title(name)
 box off
 
 
% % %set x limits
all_values=[max(abs(xdata));max(abs(ydata));max(abs(zdata))];
max_value=1.2*max(all_values);
 if max_value==0
     max_value=1;
 else
 xlim([-max_value max_value])
 ylim([-max_value max_value])
 end
%  
% % %define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E A/m'));
text(-max_value,0.95*-max_value,ticksize);

% % 
% % %plot axes
 plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')
% % 
% % %axes labels
text(0.04*max_value,.95*max_value,'Up')
text(-0.1*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.09*max_value,-.93*max_value,'E')
text(-0.97*max_value,0.05*max_value,'S')
text(0.91*max_value,0.05*max_value,'N')


% % %remanence plot
subplot(4,6,15)
plot(steps,mdata./mdata(1),'k.-')
if max(mdata)==0
xlim([0 1.1*max(steps)])
ylim([0 1.1])
else
xlim([0 1.1*max(steps)])
ylim([0 1.1*max(mdata./mdata(1))])
end
grid off
box off
Mo=strcat('Mo=',num2str(mdata(1),'%.2E A/m'));
text(0.05*max(steps),0.095,Mo);

% % %stereonet subplot
% % 
data.I=zeros(length(mdata),1);
data.D=zeros(length(mdata),1);
% 
% % %convert to polar coordinates
for i=1:length(steps)
    data.I(i)=-(rad2deg(acos(zdata(i)/sqrt(xdata(i)^2+ydata(i)^2+zdata(i)^2)))-90);
    data.D(i)=wrapTo360(rad2deg(atan2(ydata(i),xdata(i))));
end

subplot(4,6,21)
    first_time=0;
for i=1:length(steps)
    if first_time==0
          hold off
          first_time=1;
    else
          hold on
    end

if data.I(i)<=0
    polarplot(deg2rad(data.D(i)),-data.I(i),'ko-','MarkerSize',5)
elseif data.I(i)>0
    polarplot(deg2rad(data.D(i)),data.I(i),'k.-','MarkerSize',15)
else
    polarplot(NaN,NaN)
end

end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};
h = zeros(2, 1);
h(1) = polarplot(NaN,NaN,'k.','MarkerSize',15);
h(2) = polarplot(NaN,NaN,'ko','MarkerSize',5);

% % %END CRETACEOUS TC
% % 




%Cretaceous direction from all sites (TC)
I=53.3;
D=17.5;


%apply directions to median curve
k_data3.x_median=mdata*cosd(I)*cosd(D);
k_data3.y_median=mdata*cosd(I)*sind(D);
k_data3.z_median=mdata*sind(I);
k_data3.m_median=sqrt(k_data3.x_median.^2+k_data3.y_median.^2+k_data3.z_median.^2);


% % %PLOT CRETACEOUS UNIDIRECTIONAL
xdata=k_data3.x_median;
ydata=k_data3.y_median;
zdata=k_data3.z_median;
mdata=k_data3.m_median;
data=k_data3;
name='c) Cretaceous (median curve) unidirectional';

% % %zijderveld


 subplot(4,6,[16 17 22 23])
 
 plot(xdata,-ydata,'k.-','MarkerSize',15)
 hold on
 plot(xdata,-zdata,'ko-','MarkerSize',5)
  title(name)
 box off
 
 

% % %set x limits
all_values=[max(abs(xdata));max(abs(ydata));max(abs(zdata))];
max_value=1.2*max(all_values);
 if max_value==0
     max_value=1;
 else
 xlim([-max_value max_value])
 ylim([-max_value max_value])
 end
%  
% % %define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E A/m'));
text(-max_value,0.95*-max_value,ticksize);

% % 
% % %plot axes
 plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')
% % 
% % %axes labels
text(0.04*max_value,.95*max_value,'Up')
text(-0.12*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.12*max_value,-.93*max_value,'E')
text(-0.97*max_value,0.05*max_value,'S')
text(0.91*max_value,0.05*max_value,'N')


% % %remanence plot
subplot(4,6,18)
plot(steps,mdata./mdata(1),'k.-')
if max(mdata)==0
xlim([0 1.1*max(steps)])
ylim([0 1.1])
else
xlim([0 1.1*max(steps)])
ylim([0 1.1*max(mdata./mdata(1))])
end
grid off
box off
Mo=strcat('Mo=',num2str(mdata(1),'%.2E A/m'));
text(0.05*max(steps),0.095,Mo);

% % %stereonet subplot

data.I=zeros(length(data),1);
data.D=zeros(length(data),1);
% 
% % %convert to polar coordinates
for i=1:length(steps)
    data.I(i)=-(rad2deg(acos(zdata(i)/sqrt(xdata(i)^2+ydata(i)^2+zdata(i)^2)))-90);
    data.D(i)=wrapTo360(rad2deg(atan2(ydata(i),xdata(i))));
end


subplot(4,6,24)
    first_time=0;
for i=1:length(steps)
    if first_time==0
          hold off
          first_time=1;
    else
          hold on
    end
    
if data.I(i)<=0
    polarplot(deg2rad(data.D(i)),-data.I(i),'ko-','MarkerSize',5)
elseif data.I(i)>0
    polarplot(deg2rad(data.D(i)),data.I(i),'k.-','MarkerSize',15)
else
    polarplot(NaN,NaN)
end

end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};
h = zeros(2, 1);
h(1) = polarplot(NaN,NaN,'k.','MarkerSize',15);
h(2) = polarplot(NaN,NaN,'ko','MarkerSize',5);
 
% % %END CRETACEOUS UNIDIRECTIONAL
% % 




x0=10;
y0=0;
set(gcf,'Units','Inches');
width=14.808;
height=8.4;
set(gcf,'position',[x0,y0,width,height])


% set(gcf,'Units','Inches');
pos = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
saveas(gcf, 'export/k_curves.pdf', 'pdf')  



