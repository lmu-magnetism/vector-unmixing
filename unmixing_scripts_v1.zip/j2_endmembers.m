close all
clear, clc


%get cretaceous (TC) curves
k_data=readtable('files/cretaceous_curves_multi_TC.csv','FileType','text','HeaderLines',1,'Delimiter',',');
k_data.Properties.VariableNames={'steps','x_lq','x_median','x_uq','y_lq','y_median','y_uq','z_lq','z_median','z_uq'};
k_data.m_median=sqrt(k_data.x_median.^2+k_data.y_median.^2+k_data.z_median.^2);

%get cretaceous (IS) curves
k_data2=readtable('files/cretaceous_curves_multi_IS.csv','FileType','text','HeaderLines',1,'Delimiter',',');
k_data2.Properties.VariableNames={'steps','x_lq','x_median','x_uq','y_lq','y_median','y_uq','z_lq','z_median','z_uq'};
k_data2.m_median=sqrt(k_data2.x_median.^2+k_data2.y_median.^2+k_data2.z_median.^2);

%get cretaceous (unidirectional) curves
k_data3=readtable('files/cretaceous_curves_unidirect.csv','FileType','text','HeaderLines',1,'Delimiter',',');
k_data3.Properties.VariableNames={'steps','m_lq','m_median','m_uq'};

%cretaceous
I=53.3;
D=17.5;

%apply directions to median curve
k_data3.x_median=k_data.m_median*cosd(I)*cosd(D);
k_data3.y_median=k_data.m_median*cosd(I)*sind(D);
k_data3.z_median=k_data.m_median*sind(I);
k_data3.m_median=sqrt(k_data3.x_median.^2+k_data3.y_median.^2+k_data3.z_median.^2);


%get normal (508) curves
n_data=readtable('files/c508J2N_curves_IS.csv','FileType','text','HeaderLines',1,'Delimiter',',');
n_data.Properties.VariableNames={'steps','x_lq','x_median','x_uq','y_lq','y_median','y_uq','z_lq','z_median','z_uq'};
n_data.m_median=sqrt(n_data.x_median.^2+n_data.y_median.^2+n_data.z_median.^2);

%get reverse (509) curves
r_data=readtable('files/c509J2R_curves_IS.csv','FileType','text','HeaderLines',1,'Delimiter',',');
r_data.Properties.VariableNames={'steps','x_lq','x_median','x_uq','y_lq','y_median','y_uq','z_lq','z_median','z_uq'};
r_data.m_median=sqrt(r_data.x_median.^2+r_data.y_median.^2+r_data.z_median.^2);


%interpolate cretaceous data to jurassic steps
k_interp.x_median=interp1(k_data.steps,k_data3.x_median,n_data.steps);
k_interp.y_median=interp1(k_data.steps,k_data3.y_median,n_data.steps);
k_interp.z_median=interp1(k_data.steps,k_data3.z_median,n_data.steps);
k_interp.m_median=interp1(k_data.steps,k_data3.m_median,n_data.steps);




%get specimens

%change directory
cd 'files\c508J2N\'

%get file list
list=cellstr(ls('*.pmd'));

%read files
for ilist=1:length(list)
%     for ilist=1:

    %open specimen file
    fid=fopen(string(list(ilist)));
    C=textscan(fid,'%s %f %f %f %f %f %f %f %f %f %f','headerlines',3);
    fclose(fid);
 
%       %extract relevant data
    steps=C{1};
    M=C{5};
     Dg=C{6};
     Ig=C{7};
     Ds=C{8};
     Is=C{9};
    
%convert to cartesian coordinates     
    for k=1:length(steps)
    Marray(ilist,k)=M(k);    
    Xarray(ilist,k)=M(k)*cosd(Ig(k))*cosd(Dg(k));
    Yarray(ilist,k)=M(k)*cosd(Ig(k))*sind(Dg(k));
    Zarray(ilist,k)=M(k)*sind(Ig(k));
    end


xdata=Xarray(ilist,:)';
ydata=Yarray(ilist,:)';
zdata=Zarray(ilist,:)';
mdata=sqrt(xdata.^2+ydata.^2+zdata.^2);
steps=[0,100,200,300,400,475,550,600,625,640,650,658,666,673,679,685,690,695,700,705,710];

name=string(list(ilist));




%calculate optimal subtraction

resolution=200;
MAD=zeros(resolution,1);
flatness=zeros(resolution,1);
weight=zeros(resolution,1);
R_squared=zeros(resolution,1);

for j=1:(resolution+1)
%assign subtraction weight (of Cretaceous direction)
weight(j)=(j-1)/resolution;
xdata_new=xdata-weight(j)*k_interp.x_median(1:end-1);
ydata_new=ydata-weight(j)*k_interp.y_median(1:end-1);
zdata_new=zdata-weight(j)*k_interp.z_median(1:end-1);
mdata_new=sqrt(xdata_new.^2+ydata_new.^2+zdata_new.^2);

%define PCA range
first=1;
last=length(mdata);


%calculate mean of each component (in PCA range)
% xmean=mean(xdata_new(first:last));
% ymean=mean(ydata_new(first:last));
% zmean=mean(zdata_new(first:last));

% %uncomment to anchor to origin
xmean=0;
ymean=0;
zmean=0;

%transform coordinates
for i=1:(last-first)
xdash(i)=xdata_new(first+i-1)-xmean;
ydash(i)=ydata_new(first+i-1)-ymean;
zdash(i)=zdata_new(first+i-1)-zmean;
end


%create orientation tensor
T=[ sum(xdash.^2)     sum(xdash.*ydash) sum(xdash.*zdash);...
    sum(xdash.*ydash) sum(ydash.^2)     sum(ydash.*zdash);...
    sum(xdash.*zdash) sum(ydash.*zdash) sum(zdash.^2)];

%calculate eigenvectors (NB: columns are the eigenvectors, not rows!)
[V, tau]=eig(T);

%calculate reference vector (determines direction of PCA)
R=[xdash(1)-xdash(end); ydash(1)-ydash(end); zdash(1)-zdash(end)];

%find column for characteristic direction (largest eigenvalue)
[M,I]=max(tau(:));
[I_row, I_col]=ind2sub(size(tau),I);
prince=V(:,I_col);

%find dot product of principal (V1) and reference direction (R)
dot_product=dot(prince,R);

%truncate dot product over -1 to 1
if dot_product<-1
    dot_product=-1;
elseif dot_product>1
    dot_product=1;
end

%give direction sense of V1
if acos(dot_product)>(pi/2)
    PD=-prince;
else
    PD=prince;
end

%calculate declination of V1
if PD(1)<0
    dec(j)=rad2deg(atan(PD(2)/PD(1)))+180;
elseif PD(1)>0 && PD(2)<=0
    dec(j)=rad2deg(atan(PD(2)/PD(1)))+360;
else
    dec(j)=rad2deg(atan(PD(2)/PD(1)));
end

%calculate inclination of V1
inc(j)=rad2deg(atan(PD(3)/sqrt(PD(1)^2+PD(2)^2)));

%sort eigenvalues
ev=sort([tau(1,1) tau(2,2) tau(3,3)],'descend');

%calculate MAD
MAD(j)=rad2deg(atan(sqrt((ev(2)+ev(3))/ev(1))));

 
%calculate R
tail=1;
range=length(mdata_new)-tail;
first_point=1;
xdatadash=xdata_new(first_point:end-tail)./mdata_new(first_point:end-tail);
ydatadash=ydata_new(first_point:end-tail)./mdata_new(first_point:end-tail);
zdatadash=zdata_new(first_point:end-tail)./mdata_new(first_point:end-tail);
R_squared(j)=sum(xdatadash)^2+sum(ydatadash)^2+sum(zdatadash)^2;
R_value(j)=sqrt(R_squared(j))/1;
kappa(j)=(range-first_point+1-1)/(range-first_point+1-R_value(j));

end

bottom=1;
top=100;

[Mopt,Iopt]=max(kappa);



optweight=weight(Iopt+bottom-1);
dPCA=dec(Iopt+bottom-1);
iPCA=inc(Iopt+bottom-1);


output.highkappa(ilist)=Mopt;
output.optweight(ilist)=optweight;
output.dPCA(ilist)=dPCA;
output.iPCA(ilist)=iPCA;



% % %PLOT SUBTRACTION
xdata_opt(:,ilist)=xdata-optweight*k_interp.x_median(1:length(xdata));
ydata_opt(:,ilist)=ydata-optweight*k_interp.y_median(1:length(xdata));
zdata_opt(:,ilist)=zdata-optweight*k_interp.z_median(1:length(xdata));

name(:,ilist)=string(name);



end

    [rows,columns]=size(xdata_opt); 

for i=1:columns
mdata_opt(:,i)=sqrt(xdata_opt(:,i).^2+ydata_opt(:,i).^2+zdata_opt(:,i).^2);
end



Marray=mdata_opt';
Xarray=xdata_opt';
Yarray=ydata_opt';
Zarray=zdata_opt';

% 
% %find median values
Mquantiles(1,:)=quantile(Marray,0.25);
Mquantiles(2,:)=quantile(Marray,0.50);
Mquantiles(3,:)=quantile(Marray,0.75);

Xquantiles(1,:)=quantile(Xarray,0.25);
Xquantiles(2,:)=quantile(Xarray,0.50);
Xquantiles(3,:)=quantile(Xarray,0.75);

Yquantiles(1,:)=quantile(Yarray,0.25);
Yquantiles(2,:)=quantile(Yarray,0.50);
Yquantiles(3,:)=quantile(Yarray,0.75);

Zquantiles(1,:)=quantile(Zarray,0.25);
Zquantiles(2,:)=quantile(Zarray,0.50);
Zquantiles(3,:)=quantile(Zarray,0.75);



f1=figure;
subplot(2,3,2)
set(gcf,'Color','w')
xlabel('Temperature step')
ylabel('Total moment (A/m)')
title({'a) C508 specimens (IS) after subtraction of Cretaceous component (TC)',''})

grey=[180 180 180]/255;

for i=1:size(Yarray,1)
hold on
plot(steps,Yarray(i,:),'Color',grey)
end

xlabel(['Temperature step (' char(176) 'C)'])
ylabel('Y moment (A/m)')
xlim([0 750])

hold on
plot(steps,Yquantiles(1,:),'go-')
hold on
plot(steps,Yquantiles(2,:),'ko-')
hold on
plot(steps,Yquantiles(3,:),'ro-')




subplot(2,3,1)

for i=1:size(Xarray,1)
hold on
plot(steps,Xarray(i,:),'Color',grey)
end


ylabel('X moment (A/m)')
xlim([0 750])
hold on
plot(steps,Xquantiles(1,:),'go-')
hold on
plot(steps,Xquantiles(2,:),'ko-')
hold on
plot(steps,Xquantiles(3,:),'ro-')


subplot(2,3,3)

for i=1:size(Zarray,1)
hold on
plot(steps,Zarray(i,:),'Color',grey)
end

set(gcf,'Color','w')
ylabel('Z moment (A/m)')
xlim([0 750])

plot(steps,Zquantiles(1,:),'go-')
hold on
plot(steps,Zquantiles(2,:),'ko-')
hold on
plot(steps,Zquantiles(3,:),'ro-')



h = zeros(4, 1);
h(4) = plot(NaN,NaN,'Color',grey);
h(3) = plot(NaN,NaN,'go-');
h(2) = plot(NaN,NaN,'ko-');
h(1) = plot(NaN,NaN,'ro-');
legend(h, 'UQ','median','LQ','specimen data','Location','northeast');









% % %PLOT C508 IS
xdata=Xquantiles(2,:);
ydata=Yquantiles(2,:);
zdata=Zquantiles(2,:);
mdata=Mquantiles(2,:);
name='b) C508 (median curve) IS after subtraction';

out.m_lq=Mquantiles(1,:);
out.median=Mquantiles(2,:);
out.m_uq=Mquantiles(3,:);

% % %zijderveld
% figure;
 set(gcf,'Color','w')
 subplot(4,6,[13 14 19 20])
 
 plot(xdata,-ydata,'k.-','MarkerSize',15)
 hold on
 plot(xdata,-zdata,'ko-','MarkerSize',5)
  title(name)
 box off
 
 
% % %set x limits
all_values=[max(abs(xdata));max(abs(ydata));max(abs(zdata))];
max_value=1.2*max(all_values);
 if max_value==0
     max_value=1;
 else
 xlim([-max_value max_value])
 ylim([-max_value max_value])
 end
%  
% % %define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E A/m'));
text(-max_value,0.95*-max_value,ticksize);

% % % % %plot axes
 plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')

% % %axes labels
text(0.04*max_value,.95*max_value,'Up')
text(-0.1*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.09*max_value,-.93*max_value,'E')
text(-0.97*max_value,0.05*max_value,'S')
text(0.91*max_value,0.05*max_value,'N')


% % %remanence plot
subplot(4,6,15)
plot(steps,mdata./mdata(1),'k.-')
if max(mdata)==0
xlim([0 1.1*max(steps)])
ylim([0 1.1])
else
xlim([0 1.1*max(steps)])
ylim([0 1.1*max(mdata./mdata(1))])
end
grid off
box off
Mo=strcat('Mo=',num2str(mdata(1),'%.2E A/m'));
text(0.05*max(steps),0.095,Mo);

% % %stereonet subplot
% % 
data.I=zeros(length(mdata),1);
data.D=zeros(length(mdata),1);
% 
% % %convert to polar coordinates
for i=1:length(steps)
    data.I(i)=-(rad2deg(acos(zdata(i)/sqrt(xdata(i)^2+ydata(i)^2+zdata(i)^2)))-90);
    data.D(i)=wrapTo360(rad2deg(atan2(ydata(i),xdata(i))));
end
% 
% 

subplot(4,6,21)
    first_time=0;
for i=1:length(steps)
    if first_time==0
          hold off
          first_time=1;
    else
          hold on
    end
%        
if data.I(i)<=0
    polarplot(deg2rad(data.D(i)),-data.I(i),'ko-','MarkerSize',5)
elseif data.I(i)>0
    polarplot(deg2rad(data.D(i)),data.I(i),'k.-','MarkerSize',15)
else
    polarplot(NaN,NaN)
end

end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};
h = zeros(2, 1);
h(1) = polarplot(NaN,NaN,'k.','MarkerSize',15);
h(2) = polarplot(NaN,NaN,'ko','MarkerSize',5);

% % 
% % 
% % %END CRETACEOUS TC
% % 



%C509 direction
I=-65.3;
D=358.8-180;


m_lq=Mquantiles(1,:);
mdata=Mquantiles(2,:);
m_uq=Mquantiles(3,:);


%apply directions to median curve
new.x_median=mdata*cosd(I)*cosd(D);
new.y_median=mdata*cosd(I)*sind(D);
new.z_median=mdata*sind(I);
new.m_median=sqrt(new.x_median.^2+new.y_median.^2+new.z_median.^2);


% % %PLOT C509 UNIDIRECTIONAL
xdata=smooth(new.x_median);
ydata=smooth(new.y_median);
zdata=smooth(new.z_median);
mdata=smooth(new.m_median);

data=new;
name='c) Idealised C509 (median) curve';

% % %zijderveld


 subplot(4,6,[16 17 22 23])
 
 plot(xdata,-ydata,'k.-','MarkerSize',15)
 hold on
 plot(xdata,-zdata,'ko-','MarkerSize',5)
  title(name)
 box off
 
 
% 
% % %set x limits
all_values=[max(abs(xdata));max(abs(ydata));max(abs(zdata))];
max_value=1.2*max(all_values);
 if max_value==0
     max_value=1;
 else
 xlim([-max_value max_value])
 ylim([-max_value max_value])
 end

% % %define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E A/m'));
text(-max_value,0.95*-max_value,ticksize);


% % %plot axes
 plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')

% % 
% % %axes labels
text(0.04*max_value,.95*max_value,'Up')
text(-0.12*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.12*max_value,-.93*max_value,'E')
text(-0.97*max_value,0.05*max_value,'S')
text(0.91*max_value,0.05*max_value,'N')

% % 
% % %remanence plot
subplot(4,6,18)
plot(steps,mdata./mdata(1),'k.-')
if max(mdata)==0
xlim([0 1.1*max(steps)])
ylim([0 1.1])
else
xlim([0 1.1*max(steps)])
ylim([0 1.1*max(mdata./mdata(1))])
end
grid off
box off
Mo=strcat('Mo=',num2str(mdata(1),'%.2E A/m'));
text(0.05*max(steps),0.095,Mo);

% % %stereonet subplot
data.I=zeros(length(data),1);
data.D=zeros(length(data),1);

% % %convert to polar coordinates
for i=1:length(steps)
    data.I(i)=-(rad2deg(acos(zdata(i)/sqrt(xdata(i)^2+ydata(i)^2+zdata(i)^2)))-90);
    data.D(i)=wrapTo360(rad2deg(atan2(ydata(i),xdata(i))));
end
% 
% 

subplot(4,6,24)
    first_time=0;
for i=1:length(steps)
    if first_time==0
          hold off
          first_time=1;
    else
          hold on
    end
%        
if data.I(i)<=0
    polarplot(deg2rad(data.D(i)),-data.I(i),'ko-','MarkerSize',5)
elseif data.I(i)>0
    polarplot(deg2rad(data.D(i)),data.I(i),'k.-','MarkerSize',15)
else
    polarplot(NaN,NaN)
end

end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};
h = zeros(2, 1);
h(1) = polarplot(NaN,NaN,'k.','MarkerSize',15);
h(2) = polarplot(NaN,NaN,'ko','MarkerSize',5);
% % 
% % %END CRETACEOUS UNIDIRECTIONAL
% % 





x0=10;
y0=0;
width=1500;
height=850;
set(gcf,'position',[x0,y0,width,height])




%change directory
cd '../../'


set(f1,'Units','points');
pos = get(f1,'Position');
set(f1,'PaperPositionMode','Auto','PaperUnits','points','PaperSize',[pos(3), pos(4)])
print(f1,'export/j2_endmembers.pdf','-dpdf','-r0')

    