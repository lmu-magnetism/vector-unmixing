close all
clear, clc


%DEKKERS AND LINSSEN CURVES

%load non-annealed curves
data1=readtable('files/lt_hematite_curves.csv','FileType','text',...
    'HeaderLines',1,'Delimiter',',');

data1.Properties.VariableNames={'T','hem2','hem3',...
'hem4','hem5','hem6'};



%load annealed curves
data2=readtable('files/ht_hematite_curves.csv','FileType','text',...
    'HeaderLines',1,'Delimiter',',');

data2.Properties.VariableNames={'T','hem2a','hem3a',...
'hem4a','hem5a','hem6a'};


%initiate plot
f1=figure;
subplot(1,3,1)
plot(data1.T,data1.hem2,'ko-')
hold on
plot(data1.T,data1.hem3,'m^-')
hold on
plot(data1.T,data1.hem4,'b*-')
hold on
plot(data1.T,data1.hem5,'rs-')
hold on
plot(data1.T,data1.hem6,'gd-')
hold on
grid off
xlim([0 700])
ylim([0 1.1])
set(gcf,'Color','w')
ylabel('Moment (normalised)')
xlabel('Demagnetisation step (\circC)')
title('a) Thermal remanence of natural (non-annealed) hematites')
legend('5.0-3.7 \mum','3.7-2.1 \mum','2.1-1.0 \mum','1.0-0.5 \mum','0.5-0.25 \mum');
legend('Location','southwest')



%initiate plot
subplot(1,3,2)
plot(data2.T,data2.hem2a,'ko-')
hold on
plot(data2.T,data2.hem3a,'m^-')
hold on
plot(data2.T,data2.hem4a,'b*-')
hold on
plot(data2.T,data2.hem5a,'rs-')
hold on
plot(data2.T,data2.hem6a,'gd-')
hold on
grid off
xlim([0 700])
ylim([0 1.1])
set(gcf,'Color','w')
ylabel('Moment (normalised)')
xlabel('Demagnetisation step (\circC)')
title('b) Thermal remanence of annealed hematites')
legend('5.0-3.7 \mum','3.7-2.1 \mum','2.1-1.0 \mum','1.0-0.5 \mum','0.5-0.25 \mum');
legend('Location','southwest')


 

%OZDEMIR AND DUNLOP CURVES

%load SD curves
data1=readtable('files/sd_hem.csv','FileType','text',...
    'HeaderLines',1,'Delimiter',',');

data1.Properties.VariableNames={'T','SD','SD_norm'};


%load MD curves
data2=readtable('files/md_hem.csv','FileType','text',...
    'HeaderLines',1,'Delimiter',',');

data2.Properties.VariableNames={'T','MD','T_norm',...
'MD_norm'};


%initiate plot
subplot(1,3,3)
plot(data1.T,smooth(data1.SD_norm),'ko-')
hold on
plot(data2.T,smooth(data2.MD_norm),'rs-')
grid off
xlim([0 730])
ylim([0 1.1])
set(gcf,'Color','w')
ylabel('Moment (normalised)')
xlabel('Demagnetisation step (\circC)')
title('c) Thermal remanence of hematite crystals')
legend('SD hematite (0.12 \mum)','MD hematite (10 x 6 x 2 mm)');
legend('Location','southwest')


%format

x0=10;
y0=200;
width=1435;
height=325;
set(gcf,'position',[x0,y0,width,height])


%export

set(f1,'Units','Inches');
pos = get(f1,'Position');
set(f1,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(f1,'export/hem_curves.pdf','-dpdf','-r0')

