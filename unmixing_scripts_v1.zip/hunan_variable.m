close all
clear, clc


%get curves
an_data=readtable('files/hunan_comp1norm_curves.csv','FileType','text','HeaderLines',1,'Delimiter',',');
an_data.Properties.VariableNames={'steps','m_lq','m_median','m_uq','x_lq','x_median','x_uq','y_lq','y_median','y_uq','z_lq','z_median','z_uq'};

ar_data=readtable('files/hunan_comp1rev_curves.csv','FileType','text','HeaderLines',1,'Delimiter',',');
ar_data.Properties.VariableNames={'steps','m_lq','m_median','m_uq','x_lq','x_median','x_uq','y_lq','y_median','y_uq','z_lq','z_median','z_uq'};

b_data=readtable('files/hunan_comp2_curves.csv','FileType','text','HeaderLines',1,'Delimiter',',');
b_data.Properties.VariableNames={'steps','m_lq','m_median','m_uq','x_lq','x_median','x_uq','y_lq','y_median','y_uq','z_lq','z_median','z_uq'};

c_data=readtable('files/hunan_comp3_curves.csv','FileType','text','HeaderLines',1,'Delimiter',',');
c_data.Properties.VariableNames={'steps','m_lq','m_median','m_uq','x_lq','x_median','x_uq','y_lq','y_median','y_uq','z_lq','z_median','z_uq'};


margins=[0.12 0.06];

%AN SUB
resolution=200;
MAD=zeros(resolution,1);
flatness=zeros(resolution,1);
weight=zeros(resolution,1);
R_squared=zeros(resolution,1);

for j=1:(resolution+1)
%assign subtraction weight (of Cretaceous direction)
weight(j)=(j-1)/resolution;
xdata=an_data.x_median-weight(j)*c_data.x_median;
ydata=an_data.y_median-weight(j)*c_data.y_median;
zdata=an_data.z_median-weight(j)*c_data.z_median;
mdata=sqrt(xdata.^2+ydata.^2+zdata.^2);

%define PCA range
first=1;
last=length(mdata);

flatness(j)=std(mdata(1:8));

% %calculate mean of each component (in PCA range)
% xmean=mean(xdata(first:last));
% ymean=mean(ydata(first:last));
% zmean=mean(zdata(first:last));

% %uncomment to anchor to origin
xmean=0;
ymean=0;
zmean=0;

%transform coordinates
for i=first:last
xdash(i)=xdata(first+i-1)-xmean;
ydash(i)=ydata(first+i-1)-ymean;
zdash(i)=zdata(first+i-1)-zmean;
end

%create orientation tensor
T=[ sum(xdash.^2)     sum(xdash.*ydash) sum(xdash.*zdash);...
    sum(xdash.*ydash) sum(ydash.^2)     sum(ydash.*zdash);...
    sum(xdash.*zdash) sum(ydash.*zdash) sum(zdash.^2)];

%calculate eigenvectors (NB: columns are the eigenvectors, not rows!)
[V, tau]=eig(T);

%calculate reference vector (determines direction of PCA)
R=[xdash(1)-xdash(end); ydash(1)-ydash(end); zdash(1)-zdash(end)];

%find column for characteristic direction (largest eigenvalue)
[M,I]=max(tau(:));
[I_row, I_col]=ind2sub(size(tau),I);
prince=V(:,I_col);

%find dot product of principal (V1) and reference direction (R)
dot_product=dot(prince,R);

%truncate dot product over -1 to 1
if dot_product<-1
    dot_product=-1;
elseif dot_product>1
    dot_product=1;
end

%give direction sense of V1
if acos(dot_product)>(pi/2)
    PD=-prince;
else
    PD=prince;
end

%calculate declination of V1
if PD(1)<0
    dec(j)=rad2deg(atan(PD(2)/PD(1)))+180;
elseif PD(1)>0 && PD(2)<=0
    dec(j)=rad2deg(atan(PD(2)/PD(1)))+360;
else
    dec(j)=rad2deg(atan(PD(2)/PD(1)));
end

%calculate inclination of V1
inc(j)=rad2deg(atan(PD(3)/sqrt(PD(1)^2+PD(2)^2)));

%sort eigenvalues
ev=sort([tau(1,1) tau(2,2) tau(3,3)],'descend');

%calculate MAD
MAD(j)=rad2deg(atan(sqrt((ev(2)+ev(3))/ev(1))));

%calculate R
tail=2;
steps=length(mdata)-tail;
xdatadash=xdata(1:end-tail)./mdata(1:end-tail);
ydatadash=ydata(1:end-tail)./mdata(1:end-tail);
zdatadash=zdata(1:end-tail)./mdata(1:end-tail);
R_squared(j)=sum(xdatadash)^2+sum(ydatadash)^2+sum(zdatadash)^2;
R_value(j)=sqrt(R_squared(j))/1;
kappa(j)=(steps-1)/(steps-R_value(j));


end


[Mopt,Iopt]=max(kappa);

f1=figure;
set(gcf,'Color','w')
subplot_tight(1,3,1,margins)
title('a) Variable subtraction from component 1N')
yyaxis left
plot(weight,kappa)
xticks([0:0.2:1])
xticklabels([0:20:100])
xlabel('% of component 3 median curve (TC) subtracted')
ylabel(['\kappa (precision parameter) after subtraction'])
hold on
plot([weight(Iopt) weight(Iopt)],[0 200],'k')
ylim([0 200])
yyaxis right
plot(weight,flatness)
ylim([0 4e-7])

an_weight=weight(Iopt);
weight=weight(Iopt);


% % %PLOT AN SUBTRACTION
xdata=an_data.x_median-weight*c_data.x_median;
ydata=an_data.y_median-weight*c_data.y_median;
zdata=an_data.z_median-weight*c_data.z_median;
mdata=sqrt(xdata.^2+ydata.^2+zdata.^2);

steps=an_data.steps;
data=an_data;
name=strcat('C508J2N (IS) minus ',{' '},num2str(weight*100),'% of Cretaceous (IS) curve');



%AR SUB

for j=1:(resolution+1)
%assign subtraction weight (of Cretaceous direction)
weight(j)=(j-1)/resolution;
xdata=ar_data.x_median-weight(j)*c_data.x_median;
ydata=ar_data.y_median-weight(j)*c_data.y_median;
zdata=ar_data.z_median-weight(j)*c_data.z_median;
mdata=sqrt(xdata.^2+ydata.^2+zdata.^2);

%define PCA range
first=1;
last=length(mdata);

flatness(j)=std(mdata(1:8));

% %calculate mean of each component (in PCA range)
% xmean=mean(xdata(first:last));
% ymean=mean(ydata(first:last));
% zmean=mean(zdata(first:last));

% %uncomment to anchor to origin
xmean=0;
ymean=0;
zmean=0;

%transform coordinates
for i=first:last
xdash(i)=xdata(first+i-1)-xmean;
ydash(i)=ydata(first+i-1)-ymean;
zdash(i)=zdata(first+i-1)-zmean;
end

%create orientation tensor
T=[ sum(xdash.^2)     sum(xdash.*ydash) sum(xdash.*zdash);...
    sum(xdash.*ydash) sum(ydash.^2)     sum(ydash.*zdash);...
    sum(xdash.*zdash) sum(ydash.*zdash) sum(zdash.^2)];

%calculate eigenvectors (NB: columns are the eigenvectors, not rows!)
[V, tau]=eig(T);

%calculate reference vector (determines direction of PCA)
R=[xdash(1)-xdash(end); ydash(1)-ydash(end); zdash(1)-zdash(end)];

%find column for characteristic direction (largest eigenvalue)
[M,I]=max(tau(:));
[I_row, I_col]=ind2sub(size(tau),I);
prince=V(:,I_col);

%find dot product of principal (V1) and reference direction (R)
dot_product=dot(prince,R);

%truncate dot product over -1 to 1
if dot_product<-1
    dot_product=-1;
elseif dot_product>1
    dot_product=1;
end

%give direction sense of V1
if acos(dot_product)>(pi/2)
    PD=-prince;
else
    PD=prince;
end

%calculate declination of V1
if PD(1)<0
    dec(j)=rad2deg(atan(PD(2)/PD(1)))+180;
elseif PD(1)>0 && PD(2)<=0
    dec(j)=rad2deg(atan(PD(2)/PD(1)))+360;
else
    dec(j)=rad2deg(atan(PD(2)/PD(1)));
end

%calculate inclination of V1
inc(j)=rad2deg(atan(PD(3)/sqrt(PD(1)^2+PD(2)^2)));

%sort eigenvalues
ev=sort([tau(1,1) tau(2,2) tau(3,3)],'descend');

%calculate MAD
MAD(j)=rad2deg(atan(sqrt((ev(2)+ev(3))/ev(1))));


%calculate R
tail=0;
steps=length(mdata)-tail;
xdatadash=xdata(1:end-tail)./mdata(1:end-tail);
ydatadash=ydata(1:end-tail)./mdata(1:end-tail);
zdatadash=zdata(1:end-tail)./mdata(1:end-tail);
R_squared(j)=sum(xdatadash)^2+sum(ydatadash)^2+sum(zdatadash)^2;
R_value(j)=sqrt(R_squared(j))/1;
kappa(j)=(steps-1)/(steps-R_value(j));


end


[Mopt,Iopt]=max(kappa);


subplot_tight(1,3,2,margins)
title('b) Variable subtraction from component 1R')
yyaxis left
plot(weight,kappa)
xticks([0:0.2:1])
xticklabels([0:20:100])
xlabel('% of component 3 median curve (TC) subtracted')
hold on
plot([weight(Iopt) weight(Iopt)],[0 1000],'k')
ylim([0 800])
yyaxis right
plot(weight,flatness)
ylim([0 4e-7])
 
ar_weight=weight(Iopt);
weight=weight(Iopt); %amount of cretaceous component to subtract


% % %PLOT AR SUBTRACTION
xdata=ar_data.x_median-weight*c_data.x_median;
ydata=ar_data.y_median-weight*c_data.y_median;
zdata=ar_data.z_median-weight*c_data.z_median;
mdata=sqrt(xdata.^2+ydata.^2+zdata.^2);

steps=ar_data.steps;
data=ar_data;
name=strcat('C508J2N (IS) minus ',{' '},num2str(weight*100),'% of Cretaceous (IS) curve');



%B SUB

resolution=200;
MAD=zeros(resolution,1);
flatness=zeros(resolution,1);
weight=zeros(resolution,1);
R_squared=zeros(resolution,1);

for j=1:(resolution+1)
%assign subtraction weight (of Cretaceous direction)
weight(j)=(j-1)/resolution;
xdata=b_data.x_median-weight(j)*c_data.x_median;
ydata=b_data.y_median-weight(j)*c_data.y_median;
zdata=b_data.z_median-weight(j)*c_data.z_median;
mdata=sqrt(xdata.^2+ydata.^2+zdata.^2);

%define PCA range
first=1;
last=length(mdata);

flatness(j)=std(mdata(1:8));

% %uncomment to anchor to origin
xmean=0;
ymean=0;
zmean=0;

%transform coordinates
for i=first:last
xdash(i)=xdata(first+i-1)-xmean;
ydash(i)=ydata(first+i-1)-ymean;
zdash(i)=zdata(first+i-1)-zmean;
end

%create orientation tensor
T=[ sum(xdash.^2)     sum(xdash.*ydash) sum(xdash.*zdash);...
    sum(xdash.*ydash) sum(ydash.^2)     sum(ydash.*zdash);...
    sum(xdash.*zdash) sum(ydash.*zdash) sum(zdash.^2)];

%calculate eigenvectors (NB: columns are the eigenvectors, not rows!)
[V, tau]=eig(T);

%calculate reference vector (determines direction of PCA)
R=[xdash(1)-xdash(end); ydash(1)-ydash(end); zdash(1)-zdash(end)];

%find column for characteristic direction (largest eigenvalue)
[M,I]=max(tau(:));
[I_row, I_col]=ind2sub(size(tau),I);
prince=V(:,I_col);

%find dot product of principal (V1) and reference direction (R)
dot_product=dot(prince,R);

%truncate dot product over -1 to 1
if dot_product<-1
    dot_product=-1;
elseif dot_product>1
    dot_product=1;
end

%give direction sense of V1
if acos(dot_product)>(pi/2)
    PD=-prince;
else
    PD=prince;
end

%calculate declination of V1
if PD(1)<0
    dec(j)=rad2deg(atan(PD(2)/PD(1)))+180;
elseif PD(1)>0 && PD(2)<=0
    dec(j)=rad2deg(atan(PD(2)/PD(1)))+360;
else
    dec(j)=rad2deg(atan(PD(2)/PD(1)));
end

%calculate inclination of V1
inc(j)=rad2deg(atan(PD(3)/sqrt(PD(1)^2+PD(2)^2)));

%sort eigenvalues
ev=sort([tau(1,1) tau(2,2) tau(3,3)],'descend');

%calculate MAD
MAD(j)=rad2deg(atan(sqrt((ev(2)+ev(3))/ev(1))));


%calculate R
tail=0;
steps=length(mdata)-tail;
xdatadash=xdata(1:end-tail)./mdata(1:end-tail);
ydatadash=ydata(1:end-tail)./mdata(1:end-tail);
zdatadash=zdata(1:end-tail)./mdata(1:end-tail);
R_squared(j)=sum(xdatadash)^2+sum(ydatadash)^2+sum(zdatadash)^2;
R_value(j)=sqrt(R_squared(j))/1;
kappa(j)=(steps-1)/(steps-R_value(j));

end


[Mopt,Iopt]=max(kappa);

% figure;
subplot_tight(1,3,3,margins)
title('c) Variable subtraction from component 2')
yyaxis left
plot(weight,kappa)
xticks([0:0.2:1])
xticklabels([0:20:100])
xlabel('% of component 3 median curve (TC) subtracted')
hold on
plot([weight(Iopt) weight(Iopt)],[0 150],'k')
ylim([0 150])
yyaxis right
plot(weight,flatness)
ylim([0 1.5e-7])
ylabel(['\sigma_{flat} after subtraction (Am^2/kg)'])

b_weight=weight(Iopt);
weight=weight(Iopt);




x0=10;
y0=50;
width=1350;
height=350;
set(gcf,'position',[x0,y0,width,height])





set(f1,'Units','points');
pos = get(f1,'Position');
set(f1,'PaperPositionMode','Auto','PaperUnits','points','PaperSize',[pos(3), pos(4)])
print(f1,'export/hunan_variable.pdf','-dpdf','-r0')


