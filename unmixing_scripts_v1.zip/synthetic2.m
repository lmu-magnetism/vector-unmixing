close all
clear, clc


%load reference curves
data=readtable('files/ref_curves.csv','FileType','text','HeaderLines',1,'Delimiter',',');
data.Properties.VariableNames={'steps','compA','compB','compC'};


%ENTER DIRECTIONS HERE

%component A directions
Da=13;    %dec
Ia=77;    %inc

%component B directions
Db=6;   %dec
Ib=4;     %inc

%component C directions
Dc=138;     %dec
Ic=-46;     %inc



%check directions within limits
if Da>360 || Da<-360 || Ia<-90 || Ia>90 
    disp('Warning: directions for component A exceed maximum (-360 > Da > 360, -90 > Ia > 90')
elseif Db>360 || Db<-360 || Ib<-90 || Ib>90 
    disp('Warning: directions for component B exceed limits (-360 > Db > 360, -90 > Ib > 90')
elseif Dc>360 || Dc<-360 || Ic<-90 || Ic>90 
    disp('Warning: directions for component C exceed limits (-360 > Dc > 360, -90 > Ic > 90')
end


%START COMPONENT A

%apply directions to component A and convert steps to Cartesian (XYZ) coordinates
data.xa=zeros(height(data),1);
data.ya=zeros(height(data),1);
data.za=zeros(height(data),1);

for i=1:length(data.steps)
    data.xa(i)=cosd(Ia)*cosd(Da)*data.compA(i);
    data.ya(i)=cosd(Ia)*sind(Da)*data.compA(i);
    data.za(i)=sind(Ia)*data.compA(i);
end

%check data
if sum(data.compA)==0
    disp('Warning: no data entered for component A')
end


    %START COMPONENT B

%apply directions to component B and convert steps to Cartesian (XYZ) coordinates
data.xb=zeros(height(data),1);
data.yb=zeros(height(data),1);
data.zb=zeros(height(data),1);

for i=1:length(data.steps)
    data.xb(i)=cosd(Ib)*cosd(Db)*data.compB(i);
    data.yb(i)=cosd(Ib)*sind(Db)*data.compB(i);
    data.zb(i)=sind(Ib)*data.compB(i);
end

    
    %check data
if sum(data.compB)==0
    disp('Warning: no data entered for component B')
end

    
    

%START COMPONENT C

%apply directions to component C and convert steps to Cartesian (XYZ) coordinates
data.xc=zeros(height(data),1);
data.yc=zeros(height(data),1);
data.zc=zeros(height(data),1);

for i=1:length(data.steps)
    data.xc(i)=cosd(Ic)*cosd(Dc)*data.compC(i);
    data.yc(i)=cosd(Ic)*sind(Dc)*data.compC(i);
    data.zc(i)=sind(Ic)*data.compC(i);
end


if sum(data.compC)==0
    disp('Warning: no data entered for component C')
end
   
    

%START PLOTTING

f1=figure;
f1.Units='pixels';
f1.Position=[0,45,0.5*1920,950];

letterlist=['a','b','c','d','e','f'];

for i=1:6
custom_colour=[(i-1)/5 0 (6-i)/5];
subplot(3,3,i)
set(gcf,'Color','w')
data.xmix=0.2*(6-i)*data.xa+0.2*(i-1)*data.xc;
data.ymix=0.2*(6-i)*data.ya+0.2*(i-1)*data.yc;
data.zmix=0.2*(6-i)*data.za+0.2*(i-1)*data.zc;
plot(data.xmix,-data.ymix,'Color',custom_colour,'Marker','.','MarkerSize',15)
hold on
plot(data.xmix,-data.zmix,'Color',custom_colour,'Marker','o','MarkerSize',5)

aweight=num2str((6-i)*20);
cweight=num2str((i-1)*20);
words=[letterlist(i) ') ' aweight '% A + ' cweight '% C'];
title(string(words))
box off

%set xy limits
all_values=[abs(data.xmix);abs(data.ymix);abs(data.zmix)];
max_value=1.2*max(all_values);
if max_value==0
    max_value=1;
else
xlim([-max_value max_value])
ylim([-max_value max_value])
end

%define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E'));
text(-0.95*max_value,1.1*-max_value,ticksize);

%plot axes
plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')

%axes labels
text(0.04*max_value,.95*max_value,'Up')
text(-0.15*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.13*max_value,-.93*max_value,'E')
text(-0.98*max_value,0.1*max_value,'S')
text(0.88*max_value,0.1*max_value,'N')


%remance plot
data.mmix=sqrt(data.xmix.^2+data.ymix.^2+data.zmix.^2);
subplot(3,3,[7 8])
hold on
plot(data.steps,data.mmix,'Color',custom_colour,'Marker','.') %not normalised
if i==6
 xlim([0 1.1*max(data.steps)])
 ylim([0 1.1])

 grid on
 box off
 ylabel('Remanence (arbitrary units)')
 xlabel('Demagnetisation step ({\circ}C)')
 Mo=strcat('Mo=',num2str(data.mmix(1),'%.2E'));
title('g) Output remanence curves')
grid off
end


%PRINCIPAL COMPONENT ANALYSIS

%set PCA range
first=12;
last=17;

%calculate mean of each component (in PCA range)
xmean=mean(data.xmix(first:last));
ymean=mean(data.ymix(first:last));
zmean=mean(data.zmix(first:last));

% %uncomment to anchor to origin
% xmean=0;
% ymean=0;
% zmean=0;


xdash=zeros(height(data),1);
ydash=zeros(height(data),1);
zdash=zeros(height(data),1);

%transform coordinates
for k=1:(last-first)
xdash(k)=data.xmix(first+k-1)-xmean;
ydash(k)=data.ymix(first+k-1)-ymean;
zdash(k)=data.zmix(first+k-1)-zmean;
end


%create orientation tensor
T=[ sum(xdash.^2)     sum(xdash.*ydash) sum(xdash.*zdash);...
    sum(xdash.*ydash) sum(ydash.^2)     sum(ydash.*zdash);...
    sum(xdash.*zdash) sum(ydash.*zdash) sum(zdash.^2)];

%calculate eigenvectors (NB: columns are the eigenvectors, not rows!)
[V, tau]=eig(T);

%calculate reference vector (determines direction of PCA)
R=[xdash(1)-xdash(end); ydash(1)-ydash(end); zdash(1)-zdash(end)];

%find column for characteristic direction (largest eigenvalue)
[M,I]=max(tau(:));
[I_row, I_col]=ind2sub(size(tau),I);
prince=V(:,I_col);

%find dot product of principal (V1) and reference direction (R)
dot_product=dot(prince,R);

%truncate dot product over -1 to 1
if dot_product<-1
    dot_product=-1;
elseif dot_product>1
    dot_product=1;
end

%give direction sense of V1
if acos(dot_product)>(pi/2)
    PD=-prince;
else
    PD=prince;
end

%calculate declination of V1
if PD(1)<0
    Dm=rad2deg(atan(PD(2)/PD(1)))+180;
elseif PD(1)>0 && PD(2)<=0
    Dm=rad2deg(atan(PD(2)/PD(1)))+360;
else
    Dm=rad2deg(atan(PD(2)/PD(1)));
end

%calculate inclination of V1
Im=rad2deg(atan(PD(3)/sqrt(PD(1)^2+PD(2)^2)));

%sort eigenvalues
ev=sort([tau(1,1) tau(2,2) tau(3,3)],'descend');

%  %calculate MAD
MAD=rad2deg(atan(sqrt((ev(2)+ev(3))/ev(1))))



%stereonet
subplot(3,3,9)
title('h) PCA directions')
if Im<=0
    polarplot(deg2rad(Dm),-Im,'Color',custom_colour,'Marker','o','MarkerSize',5)
elseif Im>0 
    polarplot(deg2rad(Dm),Im,'Color',custom_colour,'Marker','.','MarkerSize',15)
else
    polarplot(NaN,NaN)
end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};
ax.ThetaColor = 'k';
h = zeros(2, 1);
hold on
h(1) = polarplot(NaN,NaN,'k.','MarkerSize',15);
h(2) = polarplot(NaN,NaN,'ko','MarkerSize',5);


end


%export
set(f1,'Units','Inches');
pos = get(f1,'Position');
set(f1,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(f1,'export/synthetic2.pdf','-dpdf','-r0')

