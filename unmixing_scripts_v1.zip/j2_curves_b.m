close all
clear, clc

%change directory
cd 'files\c509J2R\'

%get file list
list=cellstr(ls('*.pmd'));

%read files
for ilist=1:length(list)

    fid=fopen(string(list(ilist)));
    C=textscan(fid,'%s %f %f %f %f %f %f %f %f %f %f','headerlines',3);
    fclose(fid);
 
%       %get relevant data
    steps=C{1};
    M=C{5};
     Dg=C{6};
     Ig=C{7};
     Ds=C{8};
     Is=C{9};
    
     
     %choose coordinate system
     %geo
     I=Ig;
     D=Dg;

     %tilt-corrected
%      I=Is;
%      D=Ds;
      
    for j=1:length(steps)
    Marray(ilist,j)=M(j);    
    Xarray(ilist,j)=M(j)*cosd(I(j))*cosd(D(j));
    Yarray(ilist,j)=M(j)*cosd(I(j))*sind(D(j));
    Zarray(ilist,j)=M(j)*sind(I(j));
    end

      
end

steps=[0,100,200,300,400,475,550,600,625,640,650,658,666,673,679,685,690,695,700,705,710,715];

% 
% %find median values
Mquantiles(1,:)=quantile(Marray,0.25);
Mquantiles(2,:)=quantile(Marray,0.50);
Mquantiles(3,:)=quantile(Marray,0.75);

Xquantiles(1,:)=quantile(Xarray,0.25);
Xquantiles(2,:)=quantile(Xarray,0.50);
Xquantiles(3,:)=quantile(Xarray,0.75);

Yquantiles(1,:)=quantile(Yarray,0.25);
Yquantiles(2,:)=quantile(Yarray,0.50);
Yquantiles(3,:)=quantile(Yarray,0.75);

Zquantiles(1,:)=quantile(Zarray,0.25);
Zquantiles(2,:)=quantile(Zarray,0.50);
Zquantiles(3,:)=quantile(Zarray,0.75);


f1=figure;
subplot(1,3,2)
set(gcf,'Color','w')
xlabel(['Temperature step (' char(176) 'C)'])
title({'b) C509J2R specimen data (in situ)',''})

grey=[180 180 180]/255;

for i=1:size(Yarray,1)
hold on
plot(steps,Yarray(i,:),'Color',grey)
end

ylabel('Y moment (A/m)')
xlim([0 750])

hold on
plot(steps,Yquantiles(1,:),'go-')
hold on
plot(steps,Yquantiles(2,:),'ko-')
hold on
plot(steps,Yquantiles(3,:),'ro-')

subplot(1,3,1)

for i=1:size(Xarray,1)
hold on
plot(steps,Xarray(i,:),'Color',grey)
end

ylabel('X moment (A/m)')
xlim([0 750])
hold on
plot(steps,Xquantiles(1,:),'go-')
hold on
plot(steps,Xquantiles(2,:),'ko-')
hold on
plot(steps,Xquantiles(3,:),'ro-')


subplot(1,3,3)

for i=1:size(Zarray,1)
hold on
plot(steps,Zarray(i,:),'Color',grey)
end

set(gcf,'Color','w')
ylabel('Z moment (A/m)')
xlim([0 750])
plot(steps,Zquantiles(1,:),'go-')
hold on
plot(steps,Zquantiles(2,:),'ko-')
hold on
plot(steps,Zquantiles(3,:),'ro-')


x0=10;
y0=50;
width=1600;
height=350;
set(gcf,'position',[x0,y0,width,height])


%change directory
cd '../../'


set(f1,'Units','points');
pos = get(f1,'Position');
set(f1,'PaperPositionMode','Auto','PaperUnits','points','PaperSize',[pos(3), pos(4)])
print(f1,'export/j2_curves_b.pdf','-dpdf','-r0')

