close all
clear, clc
set(0,'DefaultFigureVisible','on') %plot figures


% %load jurassic 508 component
j_data=readtable('files/jurassic508_subtracted_ideal.csv','FileType','text','HeaderLines',1,'Delimiter',',');
j_data.Properties.VariableNames={'steps','lq','median','uq'};


comp1=j_data.median;
comp1_lq=j_data.lq;
comp1_uq=j_data.uq;
comp1_n=9;
comp1_unc=1.58*(comp1_uq(1)-comp1_lq(1))/sqrt(comp1_n);


% get cretaceous (TC) curves
k_data=readtable('files/cretaceous_curves_multi_TC.csv','FileType','text','HeaderLines',1,'Delimiter',',');
k_data.Properties.VariableNames={'steps','x_lq','x_median','x_uq','y_lq','y_median','y_uq','z_lq','z_median','z_uq'};
k_data.m_median=sqrt(k_data.x_median.^2+k_data.y_median.^2+k_data.z_median.^2);



comp2=k_data.m_median;
comp2_lq=sqrt(k_data.x_lq.^2+k_data.y_lq.^2+k_data.z_lq.^2);
comp2_uq=sqrt(k_data.x_uq.^2+k_data.y_uq.^2+k_data.z_uq.^2);
comp2_n=16;
comp2_unc=1.58*(comp2_uq(1)-comp2_lq(1))/sqrt(comp2_n);


%cretaceous direction
I=50.6;
D=18;


 
k_data.x_median=k_data.m_median*cosd(I)*cosd(D);
k_data.y_median=k_data.m_median*cosd(I)*sind(D);
k_data.z_median=k_data.m_median*sind(I);
k_data.m_median=sqrt(k_data.x_median.^2+k_data.y_median.^2+k_data.z_median.^2);

%enter resolution of fitting matrix
resolution=40;

%ENTER DIRECTIONS HERE

%site 509 mean directions (IS)
Da=358.8-180;    %dec
Ia=-65.3;    %inc



%check directions within limits
if Da>360 || Da<-360 || Ia<-90 || Ia>90 
    disp('Warning: directions for component A exceed maximum (-360 > Da > 360, -90 > Ia > 90')
end

%apply directions to component and convert steps to Cartesian (XYZ) coordinates
data.xa=zeros(height(j_data),1);
data.ya=zeros(height(j_data),1);
data.za=zeros(height(j_data),1);

for i=1:height(j_data)
    data.xa(i)=cosd(Ia)*cosd(Da)*j_data.median(i);
    data.ya(i)=cosd(Ia)*sind(Da)*j_data.median(i);
    data.za(i)=sind(Ia)*j_data.median(i);
end



% % %PLOT INPUT COMPONENT A (JURASSIC)
xdata=data.xa;
ydata=data.ya;
zdata=data.za;
mdata=sqrt(xdata.^2+ydata.^2+zdata.^2);
steps=[0,100,200,300,400,475,550,600,625,640,650,658,666,673,679,685,690,695,700,705,710,715];
steps=steps(1:length(mdata));

name=strcat('Input component 1');

%interpolate cretaceous data to jurassic steps
data.xc=interp1(k_data.steps,k_data.x_median,j_data.steps);
data.yc=interp1(k_data.steps,k_data.y_median,j_data.steps);
data.zc=interp1(k_data.steps,k_data.z_median,j_data.steps);
   
    %get specimen data
    
    %change directory
cd 'files\c509J2R\'

%get file list
list=cellstr(ls('*.pmd'));

 for ilist=2
     
       %open specimen file
    fid=fopen(string(list(ilist)));
    C=textscan(fid,'%s %f %f %f %f %f %f %f %f %f %f','headerlines',3);
    fclose(fid);
 
%       %extract relevant data
    steps=C{1};
    M=C{5};
     Dg=C{6};
     Ig=C{7};
     Ds=C{8};
     Is=C{9};
    
%convert to cartesian coordinates     
    for k=1:length(steps)
    data2.xmix(k,1)=M(k)*cosd(Ig(k))*cosd(Dg(k));
    data2.ymix(k,1)=M(k)*cosd(Ig(k))*sind(Dg(k));
    data2.zmix(k,1)=M(k)*sind(Ig(k));
    end
 end
 

 
 
 
  
% % %PLOT SPECIMEN DATA
xdata=data2.xmix;
ydata=data2.ymix;
zdata=data2.zmix;
mdata=sqrt(xdata.^2+ydata.^2+zdata.^2);

zero_fit=sum(mdata);

steps=[0,100,200,300,400,475,550,600,625,640,650,658,666,673,679,685,690,695,700,705,710];
steps=steps(1:length(mdata));

name=strcat('a) Original data from specimen 5072 (IS)');

% % %zijderveld
f1=figure;
 set(gcf,'Color','w')
 subplot(4,6,[1 2 7 8])

plot(xdata,-ydata,'k.-','MarkerSize',15)
 hold on
 plot(xdata,-zdata,'ko-','MarkerSize',5)
  title(name)
 box off
% 
% % %set x limits
all_values=[abs(xdata);abs(ydata);abs(zdata)];
max_value=1.2*max(all_values);
 if max_value==0
     max_value=1;
 else
 xlim([-max_value max_value])
 ylim([-max_value max_value])
 end
%  
% % %define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E A/m'));
text(-max_value,0.95*-max_value,ticksize);


% % %plot axes
 plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')


% % %axes labels
text(0.04*max_value,.95*max_value,'Up')
text(-0.1*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.09*max_value,-.93*max_value,'E')
text(-0.97*max_value,0.06*max_value,'S')
text(0.91*max_value,0.06*max_value,'N')

% % %remanence plot
subplot(4,6,3)
plot(steps,mdata./mdata(1),'k.-')
if max(mdata)==0
xlim([0 1.1*max(steps)])
ylim([0 1.1])
else
xlim([0 1.1*max(steps)])
ylim([0 1.1*max(mdata./mdata(1))])
end
grid off
box off
ylabel('M/Mo')
xlabel('step ({\circ}C)')
Mo=strcat('Mo=',num2str(mdata(1),'%.2E A/m'));
text(0.05*max(steps),0.095,Mo);

% % %stereonet subplot
% % 
data.I=zeros(length(data2),1);
data.D=zeros(length(data2),1);

% % %convert to polar coordinates
for i=1:length(steps)
    data.I(i)=-(rad2deg(acos(zdata(i)/sqrt(xdata(i)^2+ydata(i)^2+zdata(i)^2)))-90);
    data.D(i)=wrapTo360(rad2deg(atan2(ydata(i),xdata(i))));
end
% 
% 
subplot(4,6,9)
    first_time=0;
for i=1:length(steps)
    if first_time==0
          hold off
          first_time=1;
    else
          hold on
    end
%        
if data.I(i)<=0
    polarplot(deg2rad(data.D(i)),-data.I(i),'ko-','MarkerSize',5)
elseif data.I(i)>0
    polarplot(deg2rad(data.D(i)),data.I(i),'k.-','MarkerSize',15)
else
    polarplot(NaN,NaN)
end

end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};
h = zeros(2, 1);
h(1) = polarplot(NaN,NaN,'k.','MarkerSize',15);
h(2) = polarplot(NaN,NaN,'ko','MarkerSize',5);
% % 
% % 
% % %END SPECIMEN DATA
% % 



 
 
 
 
%make grid
max_weight=3;
points=resolution+1;
residual=zeros(points,points);
for i=1:points;
    for j=1:points;
        array.x=max_weight/resolution*(i-1)*data.xa+max_weight/resolution*(j-1)*data.xc;
        array.y=max_weight/resolution*(i-1)*data.ya+max_weight/resolution*(j-1)*data.yc;
        array.z=max_weight/resolution*(i-1)*data.za+max_weight/resolution*(j-1)*data.zc;    
        
        subtract.x=data2.xmix-array.x(1:length(steps));
        subtract.y=data2.ymix-array.y(1:length(steps));
        subtract.z=data2.zmix-array.z(1:length(steps));
        subtract.m=sqrt(subtract.x.^2+subtract.y.^2+subtract.z.^2);
        
        residual(i,j)=sum(subtract.m);
    end
end




% figure;

subplot(4,6,[13 15 19 21])
%plot  contour
%switch X and Y axes to match ndgrid convention 
residual = permute(residual,[2 1]);
contourf(residual,resolution)
xticks([1:resolution/12:points])
yticks([1:resolution/12:points])

xlabel('Component 1 weighting (%)')
ylabel('Component 2 weighting (%)')

xlim([1 points])
ylim([1 points])

xticklabels([0:max_weight*100/12:max_weight*100])
yticklabels([0:max_weight*100/12:max_weight*100])

title('c) Residuals for unmixing specimen 5072 with median curves')
c = colorbar;
c.Label.String = 'sum of residuals (A/m)';
set(gcf,'Color','w')

smallest_residual=min(residual(:));
[row,col] = find(residual==smallest_residual);
weighting2=max_weight/resolution*(row-1);
weighting1=max_weight/resolution*(col-1);

% zero_fit=sum(data2.mmix);
goodness=(zero_fit-smallest_residual)/zero_fit*100;



  
% % %PLOT MODELLED SPECIMEN 

xdata=weighting1*data.xa+weighting2*data.xc;
ydata=weighting1*data.ya+weighting2*data.yc;
zdata=weighting1*data.za+weighting2*data.zc;
mdata=sqrt(xdata.^2+ydata.^2+zdata.^2);
steps=[0,100,200,300,400,475,550,600,625,640,650,658,666,673,679,685,690,695,700,705,710];



name=strcat('b) Best fitting model (mixing components 1 and 2)');

% % %zijderveld
% figure;
 subplot(4,6,[4 5 10 11])
plot(xdata,-ydata,'k.-','MarkerSize',15)
 hold on
 plot(xdata,-zdata,'ko-','MarkerSize',5)
  title(name)
 box off
% 
% % %set x limits
all_values=[abs(xdata);abs(ydata);abs(zdata)];
max_value=1.2*max(all_values);
 if max_value==0
     max_value=1;
 else
 xlim([-max_value max_value])
 ylim([-max_value max_value])
 end
%  
% % %define ticks
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick=max_value*[-1 -0.75 -0.50 -0.25 0 0.25 0.5 0.75 1];
ax.YTick=ax.XTick;
ax.XTickLabel=[];
ax.YTickLabel=[];
ticksize=strcat('ticks=',num2str(max_value*0.25,'%.2E A/m'));
text(-max_value,0.95*-max_value,ticksize);

% % 
% % %plot axes
 plot([-max_value max_value],[0 0],'k-')
hold on
plot([0 0],[-max_value max_value],'k-')

% % %axes labels
text(0.04*max_value,.95*max_value,'Up')
text(-0.1*max_value,.95*max_value,'W')
text(0.04*max_value,-.93*max_value,'Down')
text(-0.09*max_value,-.93*max_value,'E')
text(-0.97*max_value,0.06*max_value,'S')
text(0.91*max_value,0.06*max_value,'N')

% % %remanence plot
subplot(4,6,6)
plot(steps,mdata(1:21)./mdata(1),'k.-')
if max(mdata)==0
xlim([0 1.1*max(steps)])
ylim([0 1.1])
else
xlim([0 1.1*max(steps)])
ylim([0 1.1*max(mdata(1:21)./mdata(1))])
end
grid off
box off
ylabel('M/Mo')
xlabel('step ({\circ}C)')
Mo=strcat('Mo=',num2str(mdata(1),'%.2E A/m'));
text(0.05*max(steps),0.095,Mo);

% % %stereonet subplot
% % 
data.I=zeros(length(data2),1);
data.D=zeros(length(data2),1);
% 
% % %convert to polar coordinates
for i=1:length(steps)
    data.I(i)=-(rad2deg(acos(zdata(i)/sqrt(xdata(i)^2+ydata(i)^2+zdata(i)^2)))-90);
    data.D(i)=wrapTo360(rad2deg(atan2(ydata(i),xdata(i))));
end

subplot(4,6,12)
    first_time=0;
for i=1:length(steps)
    if first_time==0
          hold off
          first_time=1;
    else
          hold on
    end
%        
if data.I(i)<=0
    polarplot(deg2rad(data.D(i)),-data.I(i),'ko-','MarkerSize',5)
elseif data.I(i)>0
    polarplot(deg2rad(data.D(i)),data.I(i),'k.-','MarkerSize',15)
else
    polarplot(NaN,NaN)
end

end
ax = gca;
d = ax.ThetaDir;
ax.ThetaDir = 'clockwise';
 ax.ThetaZeroLocation = 'top';
 ax.ThetaAxisUnits = 'degrees';
ax.RDir = 'reverse';
ax.RLim = [0 90];
ax.RTickLabel = [];
ax.ThetaTickLabel = {'0','','','90','','','180','','','270','',''};
h = zeros(2, 1);
h(1) = polarplot(NaN,NaN,'k.','MarkerSize',15);
h(2) = polarplot(NaN,NaN,'ko','MarkerSize',5);

% % 
% % %END MODELLED SPECIMEN
% % 



% % % %PLOT MODELLED SPECIMEN 
% 
data2.xfit=weighting1*data.xa+weighting2*data.xc;
data2.yfit=weighting1*data.ya+weighting2*data.yc;
data2.zfit=weighting1*data.za+weighting2*data.zc;


%average cosine similarity
for i=1:length(data2.xmix)
data2.cossim(i)=(data2.xmix(i)*data2.xfit(i)+...
    data2.ymix(i)*data2.yfit(i)+...
    data2.zmix(i)*data2.zfit(i))/...
    (sqrt(data2.xmix(i)^2+data2.ymix(i)^2+data2.zmix(i)^2)*...
    sqrt(data2.xfit(i)^2+data2.yfit(i)^2+data2.zfit(i)^2));
end

acs=mean(data2.cossim);



subplot(4,6,[16 18 22 24])

axis off
box off

vshift=0.03;
hshift=0.05;


weighting1=2.05;
weighting2=0.25;
goodness=82.69535;
acs=0.988855;
total_NRM=sum(weighting1*comp1(1)+weighting2*comp2(1));
comp1_lq=1.2;
comp1_uq=2.75;
comp2_lq=0.15;
comp2_uq=0.35;



words=['Parameters:'];
text(0.1-hshift,1-vshift,words)
words=['Resolution of 2D matrix'];
text(0.15-hshift,0.93-vshift,words)
words=[num2str(resolution) 'x' num2str(resolution)];
text(0.45-hshift,0.93-vshift,words)
words=['# of simulations'];
text(0.15-hshift,0.86-vshift,words)
words=['1 (simple)'];
text(0.45-hshift,0.86-vshift,words)
words=['Average cosine similarity'];
text(0.15-hshift,0.79-vshift,words)
words=[num2str(acs,'%.3f')];
text(0.45-hshift,0.79-vshift,words)
words=['Goodness of fit [%]'];
text(0.15-hshift,0.72-vshift,words)
words=[num2str(goodness,'%.1f')];
text(0.45-hshift,0.72-vshift,words)

words=['Component 1 median'];
text(0.45-hshift,.6-vshift,words)

words=['Best-fit weighting [%]'];
text(0.1-hshift,0.53-vshift,words)
words=[num2str(weighting1*100,'%.1f')];
text(0.45-hshift,.53-vshift,words)

words=['Estimated NRM [A/m]'];
text(0.1-hshift,0.46-vshift,words)
words=[num2str(weighting1*comp1(1),'%.2s')];
text(0.45-hshift,0.46-vshift,words)

words=['Proportion of total NRM [%]'];
text(0.1-hshift,.39-vshift,words)
words=[num2str(weighting1*comp1(1)/total_NRM*100,'%.1f')];
text(0.45-hshift,.39-vshift,words)

words=['Component 2 median'];
text(0.45-hshift,.27-vshift,words)
 
words=['Best-fit weighting [%]'];
text(0.1-hshift,0.2-vshift,words)
words=[num2str(weighting2*100,'%.1f')];
text(0.45-hshift,.2-vshift,words)

words=['Estimated NRM [A/m]'];
text(0.1-hshift,0.13-vshift,words)
words=[num2str(weighting2*comp2(1),'%.2s')];
text(0.45-hshift,0.13-vshift,words)
 
words=['Proportion of total NRM [%]'];
text(0.1-hshift,.06-vshift,words)
words=[num2str(weighting2*comp2(1)/total_NRM*100,'%.1f')];
text(0.45-hshift,.06-vshift,words)


x0=10;
y0=50;
width=1500;
height=900;
set(gcf,'position',[x0,y0,width,height])

%change directory
cd '..\..\'

set(f1,'Units','Inches');
pos = get(f1,'Position');
set(f1,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(f1,'export/modelling_5072_simple.pdf','-dpdf','-r0')
  


