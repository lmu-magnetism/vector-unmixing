close all
clear, clc

%load specimen data
data=readtable('files/hunan2019_AR_data.csv','FileType','text',...
    'HeaderLines',1,'Delimiter',',');

data.Properties.VariableNames={'specimen','state','temp','run',...
'Mx','My','Mz','M','Dc','Ic',...
    'Dg','Ig','Ds','Is',...
    'a95','holder','azimuth','hade','bed_azi','bed_dip','height','mass','suscNRM'};


list_AR=(['YF9848A';...
    'YG0870A';...
    'YG1932A';...
    'YG1939A';...
    'YG1946A';...
    'YG2231A';...
    'YG2241A';...
    'YG3510A';...
    'YG4870A';...
    'YG4876A';...
    'YG5799A']);



for i=1:length(list_AR)
   filter1=(string(data.specimen)==string(list_AR(i,:)));
   steps=data.temp(filter1);
  
   %choose coordinate system
   I=data.Is(filter1);
   D=data.Ds(filter1);
   M=data.M(filter1);

      %get mass
   list_mass=data.mass(filter1);
   mass=list_mass(1);
   
   %tilt-corrected, mass normalised     
    M_mass=M./mass*1000;    
    Mx_mass=M.*cosd(I).*cosd(D)./mass*1000;
    My_mass=M.*cosd(I).*sind(D)./mass*1000;
    Mz_mass=M.*sind(I)./mass*1000;
    
 
  
   %raw
   M=data.M(filter1)*10000;
   Mx=data.Mx(filter1)*10000;
   My=data.My(filter1)*10000;
   Mz=data.Mz(filter1)*10000;
   
   max_step=17;
   output.steps(:,i)=steps(1:max_step);
   
   %raw
   output.M(:,i)=M(1:max_step);
   output.Mx(:,i)=Mx(1:max_step);
   output.My(:,i)=My(1:max_step);
   output.Mz(:,i)=Mz(1:max_step);
   
   %mass normalised
   output.M_mass(:,i)=M_mass(1:max_step);
   output.Mx_mass(:,i)=Mx_mass(1:max_step);
   output.My_mass(:,i)=My_mass(1:max_step);
   output.Mz_mass(:,i)=Mz_mass(1:max_step);
   
end

Marray=output.M_mass';
Xarray=output.Mx_mass';
Yarray=output.My_mass';
Zarray=output.Mz_mass';
steps=output.steps;

Mquantiles(1,:)=quantile(Marray,0.25);
Mquantiles(2,:)=quantile(Marray,0.50);
Mquantiles(3,:)=quantile(Marray,0.75);

Xquantiles(1,:)=quantile(Xarray,0.25);
Xquantiles(2,:)=quantile(Xarray,0.50);
Xquantiles(3,:)=quantile(Xarray,0.75);

Yquantiles(1,:)=quantile(Yarray,0.25);
Yquantiles(2,:)=quantile(Yarray,0.50);
Yquantiles(3,:)=quantile(Yarray,0.75);

Zquantiles(1,:)=quantile(Zarray,0.25);
Zquantiles(2,:)=quantile(Zarray,0.50);
Zquantiles(3,:)=quantile(Zarray,0.75);

table=[steps(:,1) Mquantiles' Xquantiles' Yquantiles' Zquantiles'];


f1=figure;
subplot(1,3,2)
set(gcf,'Color','w')
xlabel('Temperature step')
ylabel('Total moment (A/m)')
title({'b) Component 1_R specimen data (TC)',''})

grey=[180 180 180]/255;

for i=1:size(Yarray,1)
hold on
plot(steps,Yarray(i,:),'Color',grey)
end

xlabel(['Temperature step (' char(176) 'C)'])
ylabel('Y moment (Am^2/kg)')
xlim([0 750])

hold on
plot(steps,Yquantiles(1,:),'go-')
hold on
plot(steps,Yquantiles(2,:),'ko-')
hold on
plot(steps,Yquantiles(3,:),'ro-')


subplot(1,3,1)

for i=1:size(Xarray,1)
hold on
plot(steps,Xarray(i,:),'Color',grey)
end


ylabel('X moment (Am^2/kg)')
xlim([0 750])
hold on
plot(steps,Xquantiles(1,:),'go-')
hold on
plot(steps,Xquantiles(2,:),'ko-')
hold on
plot(steps,Xquantiles(3,:),'ro-')


subplot(1,3,3)

for i=1:size(Zarray,1)
hold on
plot(steps,Zarray(i,:),'Color',grey)
end

set(gcf,'Color','w')
ylabel('Z moment (Am^2/kg)')
xlim([0 750])
plot(steps,Zquantiles(1,:),'go-')
hold on
plot(steps,Zquantiles(2,:),'ko-')
hold on
plot(steps,Zquantiles(3,:),'ro-')

x0=10;
y0=50;
width=1300;
height=300;
set(gcf,'position',[x0,y0,width,height])


%export

set(f1,'Units','points');
pos = get(f1,'Position');
set(f1,'PaperPositionMode','Auto','PaperUnits','points','PaperSize',[pos(3), pos(4)])
set(gcf,'renderer','opengl'); 
print(f1,'export/hunan_specimens_b.pdf','-dpdf','-r0')



